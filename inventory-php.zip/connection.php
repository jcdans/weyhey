<?php
	$servername = "127.0.0.1";
	$databasename = "inventory";
	$user = "root";
	$password = "";
						
	$connection = mysqli_connect($servername, $user, $password, $databasename);
?>