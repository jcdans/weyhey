<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<center>
		<?php
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			include '../connection.php';
			$username = $_SESSION['username'];
			$image = $_FILES['image']['tmp_name'];
			$img = file_get_contents($image);
			if(!$connection) 
			{
				die('Connection Failed: ' . mysqli_connect_error());
			}

			$sql = "SELECT img_user FROM images WHERE img_user = '$username'";
			$res = mysqli_query($connection, $sql);

			$sql2 = "DELETE FROM images WHERE img_user = '$username'";
			$res2 = mysqli_query($connection, $sql2);

			$sql3 = "INSERT INTO images (image, img_user) VALUES(?, '$username')";
			$stmt = mysqli_prepare($connection, $sql3);
			mysqli_stmt_bind_param($stmt, "s", $img);
			mysqli_stmt_execute($stmt);
			$check = mysqli_stmt_affected_rows($stmt);
			
			if (mysqli_num_rows($res) > 0)
			{
				if ($res2)
				{
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Changed.</b>
						</td></tr></table></div>
						</div>";
				}
				else
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Uploading.</b>
						</td></tr></table></div>
						</div>";
				}
			}
			else
			{
				if($check == 1)
				{
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Changed.</b>
						</td></tr></table></div>
						</div>";
				}
				else
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Uploading.</b>
						</td></tr></table></div>
						</div>";
				}
			}
		mysqli_close($connection);
		}
		?>
		<br/><br/><br/>
		<h2 align = "center" class="input1">Change Profile Picture</h2>
		<form action="" method="post" enctype="multipart/form-data">
			<input type="file" name="image" />
			<button>Upload</button>
		</form>
		<br/><br/><br/>
		<a href='../admin/profile.php' class='input1'>Back</a>
		</center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>