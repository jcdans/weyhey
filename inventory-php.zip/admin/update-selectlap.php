<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
		<?php include "../admin/header.php"; ?>
		<br/><br/><br/><br/>
		<div class="container1">
		<div class="addcontainer">
			<fieldset>
				<table align="center">
				<form method="POST"  action="updatelap.php">
				<tr>
					<td>&nbsp;&nbsp;Select Laptop to UPDATE:</td>
				</tr>
				<tr>
					<td>
					<?php
					include '../connection.php';
					if(!$connection) 
					{ 
						die('Connection Failed: ' . mysqli_connect_error());
					}		
					$sql = "SELECT lap_host, lap_serial FROM laptop";
					$result = mysqli_query($connection, $sql);
					if(!$result)
					{
						echo mysqli_error($connection);
					}
					elseif (mysqli_num_rows($result) > 0) 
					{
						while($row = mysqli_fetch_assoc($result)) 
						{
							echo "<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_host' value=' ' required>"; 
							echo "<option value=''>Hostname - ROW</option>";
							foreach($result as $value)
							{
								$lap = $value['lap_host'] . ' - ' . $value['lap_serial'];
								echo "<option value='{$value['lap_host']}'>{$lap}</option>"; 
							} 
							echo "</select>"; 
							
						}
		}
		else 
		{
			echo "<select class='input1' 
					style='color: black;
					padding-left:10px;
					margin: 10px;
					margin-top: 12px;
					margin-left: 18px;
					width: 505px;
					height: 35px;
					border: 1px solid #c7d0d2;
					border-radius: 2px;
					box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
					-webkit-transition: all .4s ease;
					-moz-transition: all .4s ease;
					transition: all .4s ease;
					transition: all .4s ease;' 
					name='lap_host' value=' ' required>"; 
			echo  "<option value=''>No Laptop Added</option>
			  </select>";
		}

			mysqli_close($connection);							
					?>
					</td>
				</tr>
				<tr align = "right">
					<td style='padding-right:10px'><input type="submit" name="selected" value="SELECT"></td>
				</tr>
				</form>
				</table>
			</fieldset>
		</div>
	</div>
	<br/><br/>
	<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>