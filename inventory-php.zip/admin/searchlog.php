<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<div class='container1'>
		<section>
		<?php
		if (isset($_POST['submitSearch']))
		{
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$search_value = $_POST["search"];
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM log WHERE log_date LIKE '%$search_value%' OR log_act LIKE '%$search_value%' OR log_status LIKE '%$search_value%' ORDER BY log_date ASC LIMIT $start_from, $num_rec_per_page"; 
			$resSearch = mysqli_query($connection, $sql); //run the query
			if (mysqli_num_rows($resSearch) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
		<section>
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>DATE</th>
				<th>ACTIVITIES / TASK DONE / TRANSACTIONS</th>
				<th>REMARKS</th>
				</tr>";		
		
				while ($rowSearch = mysqli_fetch_assoc($resSearch)) 
				{
					$wordwrap1 = wordwrap($rowSearch['log_act'], 50, '<br/>', true);
					$wordwrap2 = wordwrap($rowSearch['log_status'], 50, '<br/>', true);

					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a href='#>' value='$rowSearch[log_date]'>$rowSearch[log_date]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a href='#>' value='$rowSearch[log_date]'>$wordwrap1</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a href='#>' value='$rowSearch[log_date]'>$wordwrap2</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					</section>";
				
				$sql1 = "SELECT * FROM log"; 

					$rs_result = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($rs_result);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<a href='log.php?page=1'>".'|<'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='log.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='log.php?page=$total_pages'>".'>|'."</a> "; // Goto last page
				}
			else 
			{
				echo "
				<table align:left>
					<tr>
						<td>No logs found.</td>
					</tr>
				</table>";
			}	
		}
		?>		
		</section>
		</div>
		<table align = 'center'>
		<tr>
			<td>
				<br/><br/>
			</td>
		</tr>
		<tr>
			<td align = "center" class='input1'><a href='javascript:history.back()'>Back</a></td>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>