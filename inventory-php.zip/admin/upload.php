<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<?php
		$uploadedStatus1 = 0; //desktop
		$uploadedStatus2 = 0; //headset
		$uploadedStatus3 = 0; //laptop
		$uploadedStatus4 = 0; //spare
		$uploadedStatus5 = 0; //log

		if (isset($_POST["submit"])) 
		{
			if (isset($_FILES["file"])) 
			{
				//if there was an error uploading the file
				if ($_FILES["file"]["error"] > 0) 
				{
					echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
				}
				else 
				{
					if (isset($_POST["selection"]) && $_POST["selection"] == "desktop")
					{
						if (file_exists($_FILES["file"]["name"])) 
						{
							unlink($_FILES["file"]["name"]);
						}
						$storagename1 = "desktop-inventory.xlsx";
						move_uploaded_file($_FILES["file"]["tmp_name"],  $storagename1);
						$uploadedStatus1 = 1;
						header('Refresh:0; url=importexcel-desk.php');
					}
					elseif (isset($_POST["selection"]) && $_POST["selection"] == "headset")
					{
						if (file_exists($_FILES["file"]["name"])) 
						{
							unlink($_FILES["file"]["name"]);
						}
						$storagename2 = "headset-inventory.xlsx";
						move_uploaded_file($_FILES["file"]["tmp_name"],  $storagename2);
						$uploadedStatus2 = 1;
						header('Refresh:0; url=importexcel-head.php');
					}
					elseif (isset($_POST["selection"]) && $_POST["selection"] == "laptop")
					{
						if (file_exists($_FILES["file"]["name"])) 
						{
							unlink($_FILES["file"]["name"]);
						}
						$storagename3 = "laptop-inventory.xlsx";
						move_uploaded_file($_FILES["file"]["tmp_name"],  $storagename3);
						$uploadedStatus3 = 1;
						header('Refresh:0; url=importexcel-lap.php');
					}
					elseif (isset($_POST["selection"]) && $_POST["selection"] == "spare")
					{
						if (file_exists($_FILES["file"]["name"])) 
						{
							unlink($_FILES["file"]["name"]);
						}
						$storagename4 = "spare-inventory.xlsx";
						move_uploaded_file($_FILES["file"]["tmp_name"],  $storagename4);
						$uploadedStatus4 = 1;
						header('Refresh:0; url=importexcel-spare.php');
					}
					elseif (isset($_POST["selection"]) && $_POST["selection"] == "log")
					{
						if (file_exists($_FILES["file"]["name"])) 
						{
							unlink($_FILES["file"]["name"]);
						}
						$storagename5 = "log-incidents.xlsx";
						move_uploaded_file($_FILES["file"]["tmp_name"],  $storagename5);
						$uploadedStatus5 = 1;
						header('Refresh:0; url=importexcel-log.php');
					}
				}
			} 
			else 
			{
				echo "No file selected <br />";
			}
		}
		?>

		<table width="600" style="margin:115px auto; background:#f8f8f8; border:1px solid #eee; padding:20px 0 25px 0;">
		<form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">
		<tr><td colspan="2" style="font:bold 15px arial; text-align:center; padding:0 0 5px 0;">Browse and Upload Your Excel File</td></tr>
		<tr>
			<td width="50%" style="font:bold 12px tahoma, arial, sans-serif; text-align:right; border-bottom:1px solid #eee; padding:5px 10px 5px 0px; border-right:1px solid #eee;">Select file:</td>
			<td width="50%" style="border-bottom:1px solid #eee; padding:5px;"><input type="file" name="file" id="file" /></td>
		</tr>
		<tr>
			<td width="50%" style="font:bold 12px tahoma, arial, sans-serif; text-align:right; border-bottom:1px solid #eee; padding:5px 10px 5px 0px; border-right:1px solid #eee;">Inventory for:</td>
			<td width="50%" style="border-bottom:1px solid #eee; padding:5px;">
				<select class='input1' 
					style='color: black;
					padding-left:10px;
					margin: 10px;
					margin-top: 12px;
					margin-left: 0px;
					width: 150px;
					height: 35px;
					border: 1px solid #c7d0d2;
					border-radius: 2px;
					box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
					-webkit-transition: all .4s ease;
					-moz-transition: all .4s ease;
					transition: all .4s ease;
					transition: all .4s ease;'
					name='selection' value=' ' required>
					<option value='desktop'>DESKTOP</option>
					<option value='headset'>HEADSET</option>
					<option value='laptop'>LAPTOP</option>
					<option value='spare'>PERIPHERALS</option>
					<option value='log'>INCIDENT</option>
					</select>
			</td>
		</tr>
		<tr>
			<td style="font:bold 12px tahoma, arial, sans-serif; text-align:right; padding:5px 10px 5px 0px; border-right:1px solid #eee;">Submit</td>
			<td width="50%" style=" padding:5px;"><input type="submit" name="submit" /></td>
		</tr>
		</table>
		<table align = "center">
		<tr align = "center">
			<td class='input1'><br/><br/><br/><a href='../admin/mainpage.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>