<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['addhead']))
			{
				include '../connection.php';
								
				$hs_num = $_POST['hs_num'];
				$hs_brand = $_POST['hs_brand'];
				$hs_model = $_POST['hs_model'];
				$hs_serial = $_POST['hs_serial'];
				$hs_type = $_POST['hs_type'];
				$hs_status = $_POST['hs_status'];
				$hs_avail = $_POST['hs_avail'];				
				$hs_release_to_real = $_POST['hs_release_to_real'];
				$hs_release_to_phone = $_POST['hs_release_to_phone'];
				$hs_release_date = $_POST['hs_release_date'];
				$hs_return_date = $_POST['hs_return_date'];
				$hs_release_by = $_POST['hs_release_by'];
				$hs_dept = $_POST['hs_dept'];
				$hs_space = $_POST['hs_space'];
				$hs_remarks = $_POST['hs_remarks'];
				$hs_stat = $_POST['hs_stat'];
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = "INSERT INTO headset (hs_num, hs_brand, hs_model, hs_serial, hs_type, hs_status, hs_release_to_real, hs_release_to_phone, hs_release_date, hs_return_date, hs_release_by, hs_dept, hs_space, hs_remarks, hs_stat) 
						VALUES ('$hs_num', '$hs_brand', '$hs_model', '$hs_serial', '$hs_type', '$hs_status', '$hs_release_to_real', '$hs_release_to_phone', '$hs_release_date', '$hs_return_date', '$hs_release_by', '$hs_dept', '$hs_space', $hs_remarks', '$hs_stat')";
						
				if(mysqli_multi_query($connection, $sql)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
				}							
			mysqli_close($connection);
			}
		?>
	</div>
	
	<br/><br/>
	<div class="container1">
		<div class="addcontainer">
			<fieldset>
			</table>
				<table align="center">
				<tr>
					<td>
						<form method="POST"  action="">
						<input style="width: 140px;" class="input1" type="text" name="hs_num" placeholder="Headset Number" autofocus required>
						<input style="width: 140px;" class="input1" type="text" name="hs_brand" placeholder="Brand">
						<input style="width: 140px;" class="input1" type="text" name="hs_model" placeholder="Model">
					</td>
				</tr>
				<tr>
					<td align="center">
						<input style="width: 140px;" class="input1" type="text" name="hs_serial" placeholder="Serial Number">
						<input style="width: 140px;" class="input1" type="text" name="hs_type" placeholder="Type">
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 512px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_status' value=''>
							<option selected value=""><b>STATUS</b></option>
							<option value="NEW">NEW</option>
							<option value="OLD">OLD</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 512px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_avail' value=''>
							<option selected value=""><b>AVAILABILITY</b></option>
							<option value="AC">ACTIVE</option>
							<option value="FR">FOR REPAIR</option>
							<option value="MS">MISSING</option>
							<option value="TP">TEMPORARY</option>
							<option value="DE">DEFECTIVE / FOR DISPOSAL</option>
							<option value="SP">SPARE</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<form method="POST"  action="">
						<input style="width: 160px;" class="input1" type="text" name="hs_release_to_real" placeholder="Released to (real name)">
						<input style="width: 160px;" class="input1" type="text" name="hs_release_to_phone" placeholder="(phone name)">
						<input style="width: 94px;" class="input1" type="text" name="hs_release_by" placeholder="Released by">
					</td>
				</tr>
				<tr>
					<td style='padding-left:18px'>
						Release date:<input style="width: 140px;" class="input1" type="date" name="hs_release_date" value="<?php echo date('Y-m-d');?>">
						Return date:<input style="width: 140px;" class="input1" type="date" name="hs_return_date" value="<?php echo date('Y-m-d');?>">
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_dept' value=''>
							<option selected value=""><b>DEPARTMENT</b></option>
							<option value="ABMP / FO">ABMP / FO</option>
							<option value="ACCOUNTING">ACCOUNTING</option>
							<option value="BILLING">BILLING</option>
							<option value="CONSOLTANT">CONSOLTANT</option>
							<option value="CRM DEV">CRM DEV</option>
							<option value="DAVAO">DAVAO</option>
							<option value="DESIGNER">DESIGNER</option>
							<option value="EDITOR">EDITOR</option>
							<option value="EVENTS">EVENTS</option>
							<option value="FINANCE">FINANCE</option>
							<option value="FO">FO</option>
							<option value="HR">HR</option>
							<option value="IT">IT</option>
							<option value="IT MANAGER">IT MANAGER</option>
							<option value="MARKETING M.">MARKETING</option>
							<option value="PDEV">PDEV</option>
							<option value="QA">QA</option>
							<option value="SALES">SALES</option>
							<option value="SALES MANAGER">SALES MANAGER</option>
							<option value="SEO">SEO</option>
							<option value="TECH ASS">TECH ASS</option>
							<option value="TL PROD">TL PROD</option>
							<option value="WEB DEV">WEB DEV</option>
							<option value="WRITER">WRITER</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_space' value=''>
							<option selected value=""><b>DEPLOYED LOCATION</b></option>
							<option value="EXPANSION">EXPANSION</option>
							<option value="OLD OPS">OLD OPS</option>
						</select>
					</td>
				</tr>
				<tr>
					<td align="center">
						<textarea style="width: 480px; height: 50px" class="input1" type="text" name="hs_remarks" rows="10" col="30" placeholder="Remarks"></textarea>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_stat' value=''>
							<option selected value=""><b>STATUS</b></option>
							<option value="ACTIVE">ACTIVE</option>
							<option value="FOR REPAIR">FOR REPAIR</option>
							<option value="SPARE">SPARE</option>
							<option value="DEFECTIVE / FOR DISPOSAL">DEFECTIVE / FOR DISPOSA</option>
						</select>
					</td>
				</tr>
				<tr>
					<td style="padding-left:20px;"><input style="padding-right:195px; padding-left:205px;" class="btn" type="submit" name="addhead" value="Add Headset"></td>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>