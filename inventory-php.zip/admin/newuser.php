<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<div class="headerconfirm">
		<?php
			if(isset($_POST['newuser']))
			{
				include '../connection.php';
				
				$emp_user = $_POST['emp_user'];
				$emp_pass = $_POST['emp_pass'];
				$emp_fname = $_POST['emp_fname'];
				$emp_lname = $_POST['emp_lname'];
				$emp_midinit = $_POST['emp_midinit'];
				$emp_address = $_POST['emp_address'];
				$emp_bday = $_POST['emp_bday'];
				$emp_cellnum = $_POST['emp_cellnum'];
				$emp_email = $_POST['emp_email'];
				$emp_type = strtoupper($_POST['emp_type']);
				$emp_status = 'AC';
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = "INSERT INTO employee (emp_user, emp_pass, emp_fname, emp_lname, emp_midinit, emp_address, emp_bday, emp_cellnum, emp_email, emp_type, emp_status) 
						VALUES ('$emp_user', '$emp_pass', '$emp_fname', '$emp_lname', '$emp_midinit', '$emp_address', '$emp_bday', '$emp_cellnum', '$emp_email', '$emp_type', '$emp_status')";
						
				if(mysqli_multi_query($connection, $sql)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
				}							
			mysqli_close($connection);
			}
		?>
	</div>
	
	<br/><br/>
	<div class="container1">
		<div class="addcontainer">
			<fieldset>
			</table>
				<table align="center">
				<tr>
					<td>
						<form method="POST"  action="">
						<input style="width: 224px;" class="input1" type="text" name="emp_user" placeholder="Username" autofocus required>
						<input style="width: 224px;" class="input1" type="password" name="emp_pass" placeholder="Password" required>
					</td>
				</tr>
				<tr>
					<td>
						<input style="width: 144px;" class="input1" type="text" name="emp_fname" placeholder="First name">
						<input style="width: 144px;" class="input1" type="text" name="emp_lname" placeholder="Last name">
						<input style="width: 115px;" class="input1" type="text" name="emp_midinit" placeholder="Middle Initial">
					</td>
				</tr>
				<tr>
					<td><input style="width: 490px;" class="input1" type="text" name="emp_address" placeholder="Address">
					</td>
				</tr>
				<tr>
					<td><input style="width: 224px;" class="input1" type="date" name="emp_bday" value="<?php echo date('Y-m-d');?>">
						<input style="width: 224px;" class="input1" type="text" name="emp_cellnum" placeholder="Cellphone number">
					</td>
				</tr>
				<tr>
					<td><input style="width: 490px;" class="input1" type="email" name="emp_email" placeholder="example@email.com">
					</td>
				</tr>
				<tr>
					<td><select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 236px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='emp_type' value=' ' required> 
							<option value=''>Choose User Type</option>
							<option value='ADMIN'>ADMIN</option>
							<option value='USER'>USER</option>
						</select></td>
				</tr>
				<tr>
					<td style="padding-left:15px;"><input style="padding-right:175px; padding-left:185px;" class="btn" type="submit" name="newuser" value="Add User/Admin"></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<table align = 'center'>
		<tr>
			<td>
				<br/><br/>
			</td>
		</tr>
		<tr>
			<td align = "center" class='input1'><a href='desktop.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>