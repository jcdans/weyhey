<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<table align = "center">
		<tr>
		 
			</tr>
		</table>
		<h3 style="text-align: center;">SUMMARY</h3>
		<div class="container1">
		<section>
		<?php
			include '../connection.php';						
			$tablerowCount = 0; 
			$tablerowCountSpare = 0; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}

			$resultdesk1 = mysqli_query($connection, "SELECT * FROM desktop WHERE desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk1 = mysqli_num_rows($resultdesk1);

			//active
			$resultdesk2 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'ACTIVE' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk2 = mysqli_num_rows($resultdesk2);

			//for repair
			$resultdesk3 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'FOR REPAIR' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk3 = mysqli_num_rows($resultdesk3);

			//defective
			$resultdesk4 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'DEFECTIVE / FOR DISPOSAL' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk4 = mysqli_num_rows($resultdesk4);

			//spare
			$resultdesk5 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'SPARE' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk5 = mysqli_num_rows($resultdesk5);

			$resulthead1 = mysqli_query($connection, "SELECT * FROM headset");
			$num_rowshead1 = mysqli_num_rows($resulthead1);

			//active
			$resulthead2 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'ACTIVE'");
			$num_rowshead2 = mysqli_num_rows($resulthead2);

			//missing
			$resulthead3 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'MISSING'");
			$num_rowshead3 = mysqli_num_rows($resulthead3);

			//for repair
			$resulthead4 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'FOR REPAIR'");
			$num_rowshead4 = mysqli_num_rows($resulthead4);

			//defective
			$resulthead5 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'DEFECTIVE / FOR DISPOSAL'");
			$num_rowshead5 = mysqli_num_rows($resulthead5);

			//spare
			$resulthead6 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'SPARE'");
			$num_rowshead6 = mysqli_num_rows($resulthead6);

			$resultlap1 = mysqli_query($connection, "SELECT * FROM laptop");
			$num_rowslap1 = mysqli_num_rows($resultlap1);

			//active
			$resultlap2 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'ACTIVE'");
			$num_rowslap2 = mysqli_num_rows($resultlap2);

			//for repair
			$resultlap3 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'FOR REPAIR'");
			$num_rowslap3 = mysqli_num_rows($resultlap3);

			//defective
			$resultlap4 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'DEFECTIVE / FOR DISPOSAL'");
			$num_rowslap4 = mysqli_num_rows($resultlap4);

			//spare
			$resultlap5 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'SPARE'");
			$num_rowslap5 = mysqli_num_rows($resultlap5);

			$resultspare2 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'MONITOR'");
			$num_rowsspare2 = mysqli_num_rows($resultspare2);

			//keyboard
			$resultspare3 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'KEYBOARD'");
			$num_rowsspare3 = mysqli_num_rows($resultspare3);

			//mouse
			$resultspare4 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'MOUSE'");
			$num_rowsspare4 = mysqli_num_rows($resultspare4);

			//processor
			$resultspare5 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'RAM'");
			$num_rowsspare5 = mysqli_num_rows($resultspare5);

			//processor
			$resultspare6 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'PROCESSOR'");
			$num_rowsspare6 = mysqli_num_rows($resultspare6);

			
				echo "
				</section>
				</div>		
				<br/>	
				<table class='table1'>
				<tr>
				<th></th>
				<th>Desktop</th>
				<th>Headset</th>
				<th>Laptop</th>
				</tr>";		
		
				while ($tablerowCount < 5) 
				{
					
					if($tablerowCount == 0){
						echo "	
						<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Total'>Total</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Total'>$num_rowsdesk1</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Total'>$num_rowshead1</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Total'>$num_rowslap1</a></td>
							
						</tr>";
					}
					else if($tablerowCount == 1){
						echo "	
						<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Active'>Active</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Active'>$num_rowsdesk2</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Active'>$num_rowshead2</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Active'>$num_rowslap2</a></td>
						
							
						</tr>";
					}
					else if($tablerowCount == 2){
						echo "	
						<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='For repair'>For Repair</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='For repair'>$num_rowsdesk3</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='For repair'>$num_rowshead4</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='For repair'>$num_rowslap3</a></td>
						
							
						</tr>";
					}
					else if($tablerowCount == 3){
						echo "	
						<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Defective / For Disposal'>Defective / For Disposal</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Defective / For Disposal'>$num_rowsdesk4</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Defective / For Disposal'>$num_rowshead5</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Defective / For Disposal'>$num_rowslap4</a></td>
						
							
						</tr>";
					}
					else if($tablerowCount == 4){
						echo "	
						<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Spare'>Spare</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Spare'>$num_rowsdesk5</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Spare'>$num_rowshead6</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='Spare'>$num_rowslap5</a></td>
						
							
						</tr>";
					}
					$tablerowCount++;
				}

				echo "
				</div>		
				<br/>	
				<table class='table1'>
				<tr>
				<th colspan='5'>Peripherals</th>
				</tr>
				<tr>
				<th>Monitor</th>
				<th>Keyboard</th>
				<th>Mouse</th>
				<th>RAM</th>
				<th>Processor</th>
				</tr>
				<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$num_rowsspare2'>$num_rowsspare2</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$num_rowsspare3'>$num_rowsspare3</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$num_rowsspare4'>$num_rowsspare4</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$num_rowsspare5'>$num_rowsspare5</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$num_rowsspare6'>$num_rowsspare6</a></td>
							
						</tr>";	

					

		?>	
		</section>
		</div>
		<br/><br/>
		<table align = "center">
		<tr>
			<td class="input1">	</td>
		</tr>
		<tr>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>  	