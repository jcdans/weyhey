<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<center>
		<?php
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			include '../connection.php';
			$username = $_SESSION['username'];
			$image = $_FILES['image']['tmp_name'];
			$img = file_get_contents($image);
			if(!$connection) 
			{
				die('Connection Failed: ' . mysqli_connect_error());
			}
			$sql = "INSERT INTO images (image, img_user) VALUES(?, '$username')";

			$stmt = mysqli_prepare($connection, $sql);
			mysqli_stmt_bind_param($stmt, "s", $img);
			mysqli_stmt_execute($stmt);

			//check if image was successfully uploaded and inputted in database
			$check = mysqli_stmt_affected_rows($stmt);
			
			if($check == 1)
			{
				echo "<div class='headerconfirm' style='background-color:#47a3da;'>
					<div class='container1'>
					<table align='center'>
					<tr>
					<td>
					<b class='b7'>Successfully Uploaded.</b>
					</td></tr></table></div>
					</div>";
			}
			else
			{
				echo "<div class='headerconfirm' style='background-color:red;'>
					<div class='container1'>
					<table align='center'>
					<tr>
					<td>
					<b class='b7'>Error in Uploading.</b>
					</td></tr></table></div>
					</div>";
			}
			mysqli_close($connection);
		}
		?>
		<br/><br/><br/>
		<h2 align = "center" class="input1">Upload Profile Picture</h2>
		<form action="" method="post" enctype="multipart/form-data">
			<input type="file" name="image" />
			<button>Upload</button>
		</form>
		<br/><br/><br/>
		<a href='../admin/profile.php' class='input1'>Back</a>
		</center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>