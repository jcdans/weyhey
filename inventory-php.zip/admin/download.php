<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<table width="600" style="margin:115px auto; background:#f8f8f8; border:1px solid #eee; padding:20px 0 25px 0;">
		<tr><td colspan="2" style="font:bold 15px arial; text-align:center; padding:0 0 5px 0;">Export Your Excel File</td></tr>
		<tr>
			<td align="center" width="50%" style=" padding:5px;"> |			
				<a href="../admin/downloadlog.php/" class="input1" style="color:blue;">Log</a> |
				<a href="../admin/downloaddesk.php/" class="input1" style="color:blue;">Desktop</a> |
				<a href="../admin/downloadhead.php/" class="input1" style="color:blue;">Headset</a> |
				<a href="../admin/downloadlap.php/" class="input1" style="color:blue;">Laptop</a> |
				<a href="../admin/downloadspare.php/" class="input1" style="color:blue;">Spare</a> |
			</td>
		</tr>
		</table>
		<table align = "center">
		<tr align = "center">
			<td class='input1'><a href='../admin/mainpage.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>