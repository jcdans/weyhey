<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['addlog']))
			{
				include '../connection.php';
								
				$log_date = $_POST['log_date'];
				$log_act = mysqli_real_escape_string($connection, $_POST['log_act']);
				$log_status = mysqli_real_escape_string($connection, $_POST['log_status']);
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = "INSERT INTO log (log_date, log_act, log_status) 
						VALUES ('$log_date', '$log_act', '$log_status')";
						
				if(mysqli_query($connection, $sql)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
				}							
			mysqli_close($connection);
			}
		?>
	</div>
	
	<br/><br/>
	<div class="container1">
		<div class="addcontainer">
			<fieldset>
			</table>
				<table align="center">
				<tr>
					<td style="padding-left:180px;">
						<form method="POST"  action="">
						<input style="width: 140px;" class="input1" type="date" name="log_date" value="<?php echo date('Y-m-d');?>" autofocus>		
					</td>
				</tr>
				<tr>
					<td style="padding-left:15px">
						<textarea style="width: 490px; height: 100px" class="input1" name="log_act" rows="50" cols="50" placeholder="Activities / Task Done / Transactions"></textarea> 
					</td>
				</tr>
				<tr>
					<td style="padding-left:15px">
						<textarea style="width: 490px; height: 100px" class="input1" name="log_status" rows="50" cols="50" placeholder="Remarks"></textarea> 
					</td>
				</tr>
				<tr>
					<td style="padding-left:20px;"><input style="padding-right:204px; padding-left:204px;" class="btn" type="submit" name="addlog" value="Add Log"></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<br/><br/>
		<center class='input1'><a href="../admin/log.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>