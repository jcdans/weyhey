<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['updatelap']))
			{
				include '../connection.php';
				
				$lap_row = $_POST['lap_row'];
				$lap_host = $_POST['lap_host'];
				//$lap_serial = $_POST['lap_serial'];
				$lap_model = $_POST['lap_model'];
				$lap_processor = $_POST['lap_processor'];
				$lap_ram = $_POST['lap_ram'];
				$lap_hd = $_POST['lap_hd'];
				$lap_type = $_POST['lap_type'];
				$lap_os = $_POST['lap_os'];
				$lap_ms = $_POST['lap_ms'];
				$lap_dept = $_POST['lap_dept'];
				$lap_space = $_POST['lap_space'];
				$lap_user_remarks = $_POST['lap_user_remarks'];
				$lap_stat = $_POST['lap_stat'];				
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = '';
				if(!empty($lap_row))
					$sql .= "`lap_row` = '$lap_row',";
				if(!empty($lap_host))
					$sql .= "`lap_host` = '$lap_host',";
				if(!empty($lap_model))
					$sql .= "`lap_model` = '$lap_model',";
				if(!empty($lap_processor))
					$sql .= "`lap_processor` = '$lap_processor',";
				if(!empty($lap_ram))
					$sql .= "`lap_ram` = '$lap_ram',";
				if(!empty($lap_hd))
					$sql .= "`lap_hd` = '$lap_hd',";
				if(!empty($lap_type))
					$sql .= "`lap_type` = '$lap_type',";
				if(!empty($lap_os))
					$sql .= "`lap_os` = '$lap_os',";
				if(!empty($lap_ms))
					$sql .= "`lap_ms` = '$lap_ms',";
				if(!empty($lap_dept))
					$sql .= "`lap_dept` = '$lap_dept',";
				if(!empty($lap_space))
					$sql .= "`lap_space` = '$lap_space',";
				if(!empty($lap_user_remarks))
					$sql .= "`lap_user_remarks` = '$lap_user_remarks',";
				if(!empty($lap_stat))
					$sql .= "`lap_stat` = '$lap_stat',";
				$sql = trim($sql,',');

				if(!empty($sql))
				{
					$sql4 = "UPDATE
					laptop
					SET
					$sql
					WHERE
					lap_host = '$lap_host'";
				}
				if(mysqli_query($connection, $sql4)) 
				{	
					echo 	"<div class='headerconfirm' style='background-color:#47a3da;'>
							<div class='container1'>
							<table align='center'>
							<tr>
							<td>
							<b class='b7'>Successfully Updated.</b>
							</td></tr>
							</table>
							</div>
						  </div>";
					header('Refresh:2; url=../admin/update-selectlap.php');
				}
				else 
				{
					echo 	"<div class='headerconfirm' style='background-color:red;'>
							<div class='container1'>
							<table align='center'>
							<tr>
							<td>
							<b class='b7'>Error in Updating.</b>
							</td></tr></table></div>
							</div>";
					header('Refresh:2; url=../admin/update-selectlap.php');
				}							
			}
			else
			{
				$selected = $_POST['lap_host'];
	echo "
	</div>

	<br/><br/>
	<div class='container1'>
		<div class='addcontainer'>
			<fieldset>
				<table align='center'>
				<form method='POST'  action='' >
				<tr>
					<td>&nbsp;&nbsp;Selected hostname: $selected</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;Input information:</td>
				</tr>";
				$sql1 = "SELECT * FROM laptop WHERE lap_host = '".$selected."'";
				$result1 = mysqli_query($connection, $sql1);
				if(!$result1)
				{
					echo mysqli_error($connection);
				}
				elseif (mysqli_num_rows($result1) > 0) 
				{
					while ($row = mysqli_fetch_assoc($result1))
					{
					echo "
				<tr>
					<td>
						<input style='width: 224px;' class='input1' type='hidden' name='lap_host' value='$row[lap_host]' placeholder='Hostname'>
					</td>
				</tr>
				<tr>
					<td>
						<input style='width: 80px;' class='input1' type='text' name='lap_row' value='$row[lap_row]' placeholder='Row' autofocus>
						<input style='width: 144px;' class='input1' type='text' name='lap_serial' value='$row[lap_serial]' placeholder='Serial No.'>
					</td>
				</tr>
				<tr>
					<td>
						<input style='width: 100px;' class='input1' type='text' name='lap_model' value='$row[lap_model]' placeholder='Model'>
						<input style='width: 224px;' class='input1' type='text' name='lap_processor' value='$row[lap_processor]' placeholder='Processor'>
						<input style='width: 80px;' class='input1' type='text' name='lap_ram' value='$row[lap_ram]' placeholder='RAM'>
					</td>
				</tr>
				<tr>
					<td><input style='width: 224px;' class='input1' type='text' name='lap_hd' value='$row[lap_hd]' placeholder='Hard Drive'>
						<input style='width: 224px;' class='input1' type='text' name='lap_type' value='$row[lap_type]' placeholder='Type'></td>
				</tr>
				<tr>
					<td><input style='width: 224px;' class='input1' type='text' name='lap_os' value='$row[lap_os]' placeholder='Operating System'>
						<input style='width: 224px;' class='input1' type='text' name='lap_ms' value='$row[lap_ms]' placeholder='Microsoft Office'></td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_dept' value=''>
							<option selected value=''>Currently selected: value='$row[lap_dept]'</option>
							<option value='ABMP / FO'>ABMP / FO</option>
							<option value='ACCOUNTING'>ACCOUNTING</option>
							<option value='BILLING'>BILLING</option>
							<option value='CONSOLTANT'>CONSOLTANT</option>
							<option value='CRM DEV'>CRM DEV</option>
							<option value='DAVAO'>DAVAO</option>
							<option value='DESIGNER'>DESIGNER</option>
							<option value='EDITOR'>EDITOR</option>
							<option value='EVENTS'>EVENTS</option>
							<option value='FINANCE'>FINANCE</option>
							<option value='FO'>FO</option>
							<option value='HR'>HR</option>
							<option value='IT'>IT</option>
							<option value='IT MANAGER'>IT MANAGER</option>
							<option value='MARKETING M.'>MARKETING</option>
							<option value='PDEV'>PDEV</option>
							<option value='QA'>QA</option>
							<option value='SALES'>SALES</option>
							<option value='SALES MANAGER'>SALES MANAGER</option>
							<option value='SEO'>SEO</option>
							<option value='TECH ASS'>TECH ASS</option>
							<option value='TL PROD'>TL PROD</option>
							<option value='WEB DEV'>WEB DEV</option>
							<option value='WRITER'>WRITER</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_space' value=''>
							<option selected value=''>Currently selected: value='$row[lap_space]'</option>
							<option value='EXPANSION'>EXPANSION</option>
							<option value='OLD OPS'>OLD OPS</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><input style='width: 448px;' class='input1' type='text' name='lap_user_remarks' value='$row[lap_user_remarks]' placeholder='User/Remarks'></td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_stat' value=''>
							<option selected value=''><b>STATUS</b></option>
							<option value='ACTIVE'>ACTIVE</option>
							<option value='FOR REPAIR'>FOR REPAIR</option>
							<option value='SPARE'>SPARE</option>
							<option value='DEFECTIVE / FOR DISPOSAL'>DEFECTIVE / FOR DISPOSA</option>
						</select>
					</td>
				</tr>
				<tr>
					<td style='padding-left:20px;'><input style='padding-right:183px; padding-left:183px;' class='btn' type='submit' name='updatelap' value='Update Laptop'></td>
				</tr>
				</form>
				</table>
				</fieldset>
		</div>
	</div>";
			}
		}
	}
	mysqli_close($connection);
	?>
	<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>