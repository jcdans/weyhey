	<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<div class='container1'>
		<section>
		<?php
		if (isset($_POST['submitSearch']))
		{
			include '../connection.php';						
			$num_rec_per_page = 1000; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$filter = $_POST["filter"];
			$filterram = $_POST["filterram"];
			$filtermb = $_POST["filtermb"];
			$filterrow = $_POST["filterrow"];
			$filterproc = $_POST["filterproc"];
			$filterhn = $_POST["filterhn"];
			$search_value = $_POST["search"];
			$start_from = ($page - 1) * $num_rec_per_page;
			switch ($filter) {
			 	case 'row':
				 	$sql = "SELECT * FROM desktop WHERE desk_row = '$filterrow'
						ORDER BY desk_row ASC LIMIT $start_from, $num_rec_per_page";
	
			 		break;

			 	case 'hostname':
			 		$sql = "SELECT * FROM desktop WHERE desk_hname = '$filterhn'
							ORDER BY desk_hname ASC LIMIT $start_from, $num_rec_per_page"; 
					
			 		break;

			 	case 'motherboard':
			 		$sql = "SELECT * FROM desktop WHERE desk_mb = '$filtermb'
								ORDER BY desk_mb ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'processor':
			 		$sql = "SELECT * FROM desktop WHERE desk_processor = '$filterproc'
								ORDER BY desk_processor ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'ram':
			 		$sql = "SELECT * FROM desktop WHERE desk_ram = '$filterram'
								ORDER BY desk_ram, desk_row ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'hd':
			 		$sql = "SELECT * FROM desktop WHERE desk_hd LIKE '%$search_value%'
								ORDER BY desk_hd ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'primarymonitor':
			 		$sql = "SELECT * FROM desktop WHERE desk_monitor_p LIKE '%$search_value%'
								ORDER BY desk_monitor_p ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'secondarymonitor':
			 		$sql = "SELECT * FROM desktop WHERE desk_monitor_s LIKE '%$search_value%'
								ORDER BY desk_monitor_s ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'type':
			 		$sql = "SELECT * FROM desktop WHERE desk_type LIKE '%$search_value%'
								ORDER BY desk_type ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'keyboard':
			 		$sql = "SELECT * FROM desktop WHERE desk_kb LIKE '%$search_value%'
								ORDER BY desk_kb ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'mouse':
			 		$sql = "SELECT * FROM desktop WHERE desk_mouse LIKE '%$search_value%'
								ORDER BY desk_mouse ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'os':
			 		$sql = "SELECT * FROM desktop WHERE desk_os LIKE '%$search_value%'
								ORDER BY desk_os ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'ms':
			 		$sql = "SELECT * FROM desktop WHERE desk_ms LIKE '%$search_value%'
								ORDER BY desk_ms ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'dept':
			 		$sql = "SELECT * FROM desktop WHERE desk_dept LIKE '%$search_value%'
								ORDER BY desk_dept ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'space':
			 		$sql = "SELECT * FROM desktop WHERE desk_space LIKE '%$search_value%'
								ORDER BY desk_space ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	case 'remarks':
			 		$sql = "SELECT * FROM desktop WHERE desk_remarks LIKE '%$search_value%'
								ORDER BY desk_remarks ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

				case 'stat':
			 		$sql = "SELECT * FROM desktop WHERE desk_stat LIKE '%$search_value%'
								ORDER BY desk_stat ASC LIMIT $start_from, $num_rec_per_page"; 
			 		break;

			 	default:
			 		$sql = "SELECT * FROM desktop
			 				ORDER BY desk_row ASC LIMIT $start_from, $num_rec_per_page";

			 		break;
			 } 
			// $sql = "SELECT * FROM desktop WHERE desk_hname LIKE '%$search_value%'
			// 		OR desk_stat LIKE '%$search_value%' 
			// 		ORDER BY desk_row ASC LIMIT $start_from, $num_rec_per_page"; 
			$resSearch = mysqli_query($connection, $sql); //run the query
					if (mysqli_num_rows($resSearch) > 0) 
					{
						$count = mysqli_num_rows($resSearch);
						echo "
				</section>
				</div>		
				<br/>
				<table align='center'> 
					<tr>
						<td></td>
					</tr>
					<tr>
						<td></td>
					</tr>
				 </table>						
				
				<table class='table1'>";

					echo"
						<tr>
						<td>
						$count desktop(s)</td>
						</tr>
						<tr>
						<th>ROW</th>
						<th>Hostname</th>
						<th>MotherBoard</th>
						<th>Processor</th>
						<th>RAM</th>
						<th>HD</th>
						<th>Primary Monitor</th>
						<th>Secondary Monitor</th>
						<th>Type</th>
						<th>Keyboard</th>
						<th>Mouse</th>
						<th>Operating System</th>
						<th>Microsoft Office</th>
						<th>Department</th>
						<th>Space</th>
						<th>Remarks</th>
						</tr>";		
						
						while ($rowSearch = mysqli_fetch_assoc($resSearch)) 
						{
							$count++;
							echo "	
							<tr class='tr1'>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_row]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a title='$rowSearch[desk_space]' value='$rowSearch[desk_row]'>$rowSearch[desk_hname]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_mb]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_processor]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_ram]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_hd]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_monitor_p]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_monitor_s]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_type]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_kb]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_mouse]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_os]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_ms]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_dept]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_space]</a></td>
								<td class='td1' style='text-align:left; font-size: 12px;'>
								<a value='$rowSearch[desk_row]'>$rowSearch[desk_remarks]</a></td>
							</tr>";
						}
							echo"</table>
							<section>
							<table>
								<tr>
									<td></td>
								</tr>
								<tr>
									<td></td>
								</tr>
							</table>
							</section>";
						
						$sql1 = "SELECT * FROM desktop"; 

							$resSearch = mysqli_query($connection, $sql1); //run the query
							$total_records = mysqli_num_rows($resSearch);  //count number of records
							$total_pages = ceil($total_records / $num_rec_per_page); 

							// echo "<a href='desktop.php?page=1'>".'|<'."</a> "; // Goto 1st page  

							// for ($i=1; $i<=$total_pages; $i++) 
							// { 
							// 	echo "<a href='desktop.php?page=".$i."'>".$i."</a> "; 
							// }
							// echo "<a href='desktop.php?page=$total_pages'>".'>|'."</a> "; // Goto last page
					}
					else 
					{
						echo "
						<table align:left>
							<tr>
								<td>No desktops found.</td>
							</tr>
						</table>";
					}
				
		}
		?>		
		<!-- </section> -->
		</div>
		<table align = 'center'>
		<tr>
			<td>
				<br/><br/>
			</td>
		</tr>
		<tr>
		<td align = 'center' class='input1'><a href='javascript:history.back()'>Back</a></td>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>