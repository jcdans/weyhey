<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<div class="headerconfirm">
			<?php
				if(isset($_POST['delhead']))
				{
					include '../connection.php';
					$hs_num = $_POST['hs_num'];
					
					if(!$connection) 
					{ 
						die('Connection Failed: ' . mysqli_connect_error());
					}
					$sql = "DELETE FROM headset WHERE hs_num = '$hs_num' LIMIT 1";
							
					if(mysqli_multi_query($connection, $sql)) 
					{	
						echo "<div class='headerconfirm' style='background-color:#47a3da;'>
							<div class='container1'>
							<table align='center'>
							<tr>
							<td>
							<b class='b7'>Successfully Deleted.</b>
							</td></tr></table></div>
							</div>";
					}
					else 
					{
						echo "<div class='headerconfirm' style='background-color:red;'>
							<div class='container1'>
							<table align='center'>
							<tr>
							<td>
							<b class='b7'>Error in Deleting.</b>
							</td></tr></table></div>
							</div>";
					}							
				mysqli_close($connection);
				}
			?>
		</div>
		
		<br/><br/>
		<div class="container1">
			<div class="addcontainer">
				<fieldset>
				<table align="center">
				<form method="POST"  action="" >
				<tr>
					<td><?php
					include '../connection.php'; 
					if(!$connection) 
					{ 
						die('Connection Failed: ' . mysqli_connect_error());
					}		
					$sql = "SELECT hs_num, hs_serial FROM headset";
					$result = mysqli_query($connection, $sql);
					if(!$result)
					{
						echo mysqli_error($connection);
					}
					elseif (mysqli_num_rows($result) > 0) 
					{
						while($row = mysqli_fetch_assoc($result)) 
						{
							echo "<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 520px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_num' value=' ' required>"; 
							echo "<option value=''>Headset No. - Serial No.</option>";
							foreach($result as $value)
							{
								echo '<option value='.$value['hs_num'].'>'.$value['hs_num'].' - '.$value['hs_serial'].'</option>'; 
							} 
							echo "</select>"; 
							
						}
					}
					else 
					{
						echo "<select class='input1' 
								style='color: black;
								padding-left:10px;
								margin: 10px;
								margin-top: 12px;
								margin-left: 18px;
								width: 520px;
								height: 35px;
								border: 1px solid #c7d0d2;
								border-radius: 2px;
								box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
								-webkit-transition: all .4s ease;
								-moz-transition: all .4s ease;
								transition: all .4s ease;
								transition: all .4s ease;' 
								name='hs_num' value=' ' required>"; 
						echo  "<option value=''>No Headset Added</option>
						  </select>";
					}

			mysqli_close($connection);							
				?></td>
				</tr>
				<tr>
					<td style="padding-left:20px;"><input style="padding-right:190px; padding-left:190px;" class="btn" type="submit" name="delhead" value="Delete Headset"></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>