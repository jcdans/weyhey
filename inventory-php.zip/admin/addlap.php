<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['addlap']))
			{
				include '../connection.php';
				
				$lap_row = $_POST['lap_row'];
				$lap_host = $_POST['lap_host'];
				$lap_serial = $_POST['lap_serial'];
				$lap_model = $_POST['lap_model'];
				$lap_processor = $_POST['lap_processor'];
				$lap_ram = $_POST['lap_ram'];
				$lap_hd = $_POST['lap_hd'];
				$lap_type = $_POST['lap_type'];
				$lap_os = $_POST['lap_os'];
				$lap_ms = $_POST['lap_ms'];
				$lap_dept = $_POST['lap_dept'];
				$lap_space = $_POST['lap_space'];
				$lap_user_remarks = $_POST['lap_user_remarks'];
				$lap_stat = $_POST['lap_stat'];
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = "INSERT INTO laptop (lap_row, lap_host, lap_serial, lap_model, lap_processor, lap_ram, lap_hd, lap_type, lap_os, lap_ms, lap_dept, lap_space, lap_user_remarks, lap_stat) 
				VALUES ('$lap_row', '$lap_host', '$lap_serial', '$lap_model', '$lap_processor', '$lap_ram', '$lap_hd', '$lap_type', '$lap_os', '$lap_ms', '$lap_dept', '$lap_space', '$lap_user_remarks', '$lap_stat')";
						
				if(mysqli_multi_query($connection, $sql)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
				}							
			mysqli_close($connection);
			}
		?>
	</div>
	
	<br/><br/>
	<div class="container1">
		<div class="addcontainer">
			<fieldset>
			</table>
				<table align="center">
				<tr>
					<td>
						<form method="POST"  action="">
						<input style="width: 80px;" class="input1" type="text" name="lap_row" placeholder="Row" autofocus>
						<input style="width: 180px;" class="input1" type="text" name="lap_host" placeholder="Hostname" required>
						<input style="width: 144px;" class="input1" type="text" name="lap_serial" placeholder="Serial No.">
					</td>
				</tr>
				<tr>
					<td>
						<input style="width: 100px;" class="input1" type="text" name="lap_model" placeholder="Model">
						<input style="width: 224px;" class="input1" type="text" name="lap_processor" placeholder="Processor">
						<input style="width: 80px;" class="input1" type="text" name="lap_ram" placeholder="RAM">
					</td>
				</tr>
				<tr>
					<td><input style="width: 224px;" class="input1" type="text" name="lap_hd" placeholder="Hard Drive">
						<input style="width: 224px;" class="input1" type="text" name="lap_type" placeholder="Type"></td>
				</tr>
				<tr>
					<td><input style="width: 224px;" class="input1" type="text" name="lap_os" placeholder="Operating System">
						<input style="width: 224px;" class="input1" type="text" name="lap_ms" placeholder="Microsoft Office"></td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_dept' value=''>
							<option selected value=""><b>DEPARTMENT</b></option>
							<option value="ABMP / FO">ABMP / FO</option>
							<option value="ACCOUNTING">ACCOUNTING</option>
							<option value="BILLING">BILLING</option>
							<option value="CONSOLTANT">CONSOLTANT</option>
							<option value="CRM DEV">CRM DEV</option>
							<option value="DAVAO">DAVAO</option>
							<option value="DESIGNER">DESIGNER</option>
							<option value="EDITOR">EDITOR</option>
							<option value="EVENTS">EVENTS</option>
							<option value="FINANCE">FINANCE</option>
							<option value="FO">FO</option>
							<option value="HR">HR</option>
							<option value="IT">IT</option>
							<option value="IT MANAGER">IT MANAGER</option>
							<option value="MARKETING M.">MARKETING</option>
							<option value="PDEV">PDEV</option>
							<option value="QA">QA</option>
							<option value="SALES">SALES</option>
							<option value="SALES MANAGER">SALES MANAGER</option>
							<option value="SEO">SEO</option>
							<option value="TECH ASS">TECH ASS</option>
							<option value="TL PROD">TL PROD</option>
							<option value="WEB DEV">WEB DEV</option>
							<option value="WRITER">WRITER</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_space' value=''>
							<option selected value=""><b>DEPLOYED LOCATION</b></option>
							<option value="EXPANSION">EXPANSION</option>
							<option value="OLD OPS">OLD OPS</option>
						</select>
					</td>
				</tr>
				<tr>
					<td><input style="width: 448px;" class="input1" type="text" name="lap_user_remarks" placeholder="User/Remarks"></td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='lap_stat' value=''>
							<option selected value=""><b>STATUS</b></option>
							<option value="ACTIVE">ACTIVE</option>
							<option value="FOR REPAIR">FOR REPAIR</option>
							<option value="SPARE">SPARE</option>
							<option value="DEFECTIVE / FOR DISPOSAL">DEFECTIVE / FOR DISPOSA</option>
						</select>
					</td>
				</tr>
				<tr>
					<td style="padding-left:20px;"><input style="padding-right:198px; padding-left:198px;" class="btn" type="submit" name="addlap" value="Add Laptop"></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>