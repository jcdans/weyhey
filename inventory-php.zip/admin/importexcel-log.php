<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
		<?php
			$inserted = FALSE;
			session_start();
			include '../connection.php';
			include '../PHPExcel/IOFactory.php';
			
			$objPHPExcel = PHPExcel_IOFactory::load('log-incidents.xlsx');
			foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
			{
				$highestRow = $worksheet->getHighestRow();
				for ($row = 0; $row <= $highestRow; $row++)
				{
					$log_date_convert = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
					if (!empty($log_date_convert) && $log_date_convert != '0000-00-00')
					{
						$log_date = date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($log_date_convert));
					}
					else
					{
						$log_date = "";
					}
					$log_act = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
					$log_status = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
					
					if ($log_act != "")
					{
						$sql = "INSERT INTO log (log_date, log_act, log_status) 
								VALUES ('".$log_date."', '".$log_act."', '".$log_status."')";
						mysqli_query($connection, $sql);
						$inserted = TRUE;
					}
				}
			}
			if($inserted === TRUE){
						date_default_timezone_set('Asia/Manila');
						$modDATE = date('F d Y H:i:s.');
						$modTYPE = "Log";
						 if(!isset($_SESSION)){ 
						        session_start(); 
						} 
						$user = $_SESSION['username'];
						$pass = $_SESSION['userpass'];
						
						$sqlemp = "SELECT * FROM employee WHERE emp_user = '$user'"; 
						$rs_employee = mysqli_query($connection, $sqlemp);
						if (mysqli_num_rows($rs_employee) > 0){
							while ($row = mysqli_fetch_assoc($rs_employee)){
								$modFName = $row["emp_fname"];
								$modMName = $row["emp_midinit"];
								$modLName = $row["emp_lname"];
							}
							$MODNAME = $modFName . " " . $modMName . ". " . $modLName;
						}
						$sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'";
						$sqlmodupdate = "UPDATE modification set mod_name = '$MODNAME', mod_date = '$modDATE' WHERE mod_type = '$modTYPE'";
						$sqlmodinsert = "INSERT INTO modification VALUES ('$MODNAME', '$modDATE', '$modTYPE')";
						$rs_mod = mysqli_query($connection, $sqlmod);
						if(mysqli_num_rows($rs_mod) > 0){
							mysqli_query($connection, $sqlmodupdate);
						}
						else
						{
							mysqli_query($connection, $sqlmodinsert);
						}
			}
		?>
		<br/><br/><br/><br/><br/>
		<center class="input1">Congratulations! Data inserted!</center>
		<?php header('Refresh:2; url=upload.php');?>
	</body>
</html>