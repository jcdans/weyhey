<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
		<?php
			$inserted = FALSE;
			session_start();
			include '../connection.php';
			include '../PHPExcel/IOFactory.php';
			
			$objPHPExcel = PHPExcel_IOFactory::load('headset-inventory.xlsx');
			foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
			{
				$highestRow = $worksheet->getHighestRow();
				for ($row = 0; $row <= $highestRow; $row++)
				{
					$hs_num = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
					$hs_brand = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
					$hs_model = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
					$hs_serial = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
					$hs_type = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
					$hs_status = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
					$hs_avail = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(6, $row)->getValue());
					$hs_release_to_real = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(7, $row)->getValue());
					$hs_release_to_phone = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(8, $row)->getValue());

					$hs_release_date_convert = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(9, $row)->getValue());
					if (!empty($hs_release_date_convert) && $hs_release_date_convert != '0000-00-00')
					{
						$hs_release_date = date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($hs_release_date_convert));
					}
					else
					{
						$hs_release_date = "";
					}

					$hs_return_date_convert = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(10, $row)->getValue());
					if (!empty($hs_return_date_convert) && $hs_return_date_convert != '0000-00-00')
					{
						$hs_return_date = date('Y-m-d', PHPExcel_Shared_Date::ExcelToPHP($hs_return_date_convert));
					}
					else
					{
						$hs_return_date = "";
					}

					$hs_release_by = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(11, $row)->getValue());
					$hs_dept = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(12, $row)->getValue());
					$hs_space = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(13, $row)->getValue());
					$hs_remarks = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(14, $row)->getValue());
					$hs_stat = "ACTIVE";
						
					if ($hs_status != "" )
					{
						$sql = "INSERT INTO headset (hs_num, hs_brand, hs_model, hs_serial, hs_type, hs_status, hs_avail, hs_release_to_real, hs_release_to_phone, hs_release_date, hs_return_date, hs_release_by, hs_dept, hs_space, hs_remarks, hs_stat) 
								VALUES ('".$hs_num."', '".$hs_brand."', '".$hs_model."', '".$hs_serial."', '".$hs_type."', '".$hs_status."', '".$hs_avail."', '".$hs_release_to_real."', '".$hs_release_to_phone."', '".$hs_release_date."', '".$hs_return_date."', '".$hs_release_by."', '".$hs_dept."', '".$hs_space."', '".$hs_remarks."', '".$hs_stat."')";
						mysqli_query($connection, $sql);
						$inserted = TRUE;
					}
				}
			}
			if($inserted === TRUE){
						date_default_timezone_set('Asia/Manila');
						$modDATE = date('F d Y H:i:s.');
						$modTYPE = "Headset";
						 if(!isset($_SESSION)){ 
						        session_start(); 
						} 
						$user = $_SESSION['username'];
						$pass = $_SESSION['userpass'];
						
						$sqlemp = "SELECT * FROM employee WHERE emp_user = '$user'"; 
						$rs_employee = mysqli_query($connection, $sqlemp);
						if (mysqli_num_rows($rs_employee) > 0){
							while ($row = mysqli_fetch_assoc($rs_employee)){
								$modFName = $row["emp_fname"];
								$modMName = $row["emp_midinit"];
								$modLName = $row["emp_lname"];
							}
							$MODNAME = $modFName . " " . $modMName . ". " . $modLName;
						}
						$sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'";
						$sqlmodupdate = "UPDATE modification set mod_name = '$MODNAME', mod_date = '$modDATE' WHERE mod_type = '$modTYPE'";
						$sqlmodinsert = "INSERT INTO modification VALUES ('$MODNAME', '$modDATE', '$modTYPE')";
						$rs_mod = mysqli_query($connection, $sqlmod);
						if(mysqli_num_rows($rs_mod) > 0){
							mysqli_query($connection, $sqlmodupdate);
						}
						else
						{
							mysqli_query($connection, $sqlmodinsert);
						}
			}
		?>
		<br/><br/><br/><br/><br/>
		<?php 
		if($inserted){
			echo "
		<center class='input1'>Congratulations! Data inserted!</center>";
		}
		else{
			echo "
		<center class='input1'>Data insertion failed!</center>";
		}
		header('Refresh:2; url=upload.php');?>
	</body>
</html>