<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
		if(isset($_POST['updatedesk']))
		{
			include '../connection.php';
			
			$desk_hname = ($_POST['desk_hname']);
			$desk_mb = ($_POST['desk_mb']);
			$desk_processor = ($_POST['desk_processor']);
			$desk_ram = ($_POST['desk_ram']);
			$desk_hd = ($_POST['desk_hd']);
			$desk_monitor_p = ($_POST['desk_monitor_p']);
			$desk_monitor_s = ($_POST['desk_monitor_s']);
			$desk_type = ($_POST['desk_type']);
			$desk_kb = ($_POST['desk_kb']);
			$desk_mouse = ($_POST['desk_mouse']);
			$desk_os = ($_POST['desk_os']);
			$desk_ms = ($_POST['desk_ms']);
			$desk_dept = ($_POST['desk_dept']);
		    $desk_space = ($_POST['desk_space']);
			$desk_remarks = ($_POST['desk_remarks']);
			$desk_stat = $_POST['desk_stat'];
			
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}
			$sql = '';
			if(!empty($desk_hname))
				$sql .= "`desk_hname` = '$desk_hname',";
			if(!empty($desk_mb))
				$sql .= "`desk_mb` = '$desk_mb',";
			if(!empty($desk_processor))
				$sql .= "`desk_processor` = '$desk_processor',";
			if(!empty($desk_ram))
				$sql .= "`desk_ram` = '$desk_ram',";
			if(!empty($desk_hd))
				$sql .= "`desk_hd` = '$desk_hd',";
			if(!empty($desk_monitor_p))
				$sql .= "`desk_monitor_p` = '$desk_monitor_p',";
			if(!empty($desk_monitor_s))
				$sql .= "`desk_monitor_s` = '$desk_monitor_s',";
			if(!empty($desk_type))
				$sql .= "`desk_type` = '$desk_type',";
			if(!empty($desk_kb))
				$sql .= "`desk_kb` = '$desk_kb',";
			if(!empty($desk_mouse))
				$sql .= "`desk_mouse` = '$desk_mouse',";
			if(!empty($desk_os))
				$sql .= "`desk_os` = '$desk_os',";
			if(!empty($desk_ms))
				$sql .= "`desk_ms` = '$desk_ms',";
			if(!empty($desk_dept))
				$sql .= "`desk_dept` = '$desk_dept',";
			if(!empty($desk_space))
				$sql .= "`desk_space` = '$desk_space',";
			if(!empty($desk_remarks))
				$sql .= "`desk_remarks` = '$desk_remarks',";
			if(!empty($desk_stat))
				$sql .= "`desk_stat` = '$desk_stat',";
			$sql = trim($sql,',');

			if(!empty($sql))
			{
				$sql4 = "UPDATE
				desktop
				SET
				$sql
				WHERE
				desk_hname = '$desk_hname'";
			}
			if(mysqli_query($connection, $sql4)) 
			{	
						date_default_timezone_set('Asia/Manila');
						$modDATE = date('F d Y H:i:s.');
						$modTYPE = "Desktop";
						 if(!isset($_SESSION)){ 
						        session_start(); 
						} 
						$user = $_SESSION['username'];
						$pass = $_SESSION['userpass'];
						
						$sqlemp = "SELECT * FROM employee WHERE emp_user = '$user'"; 
						$rs_employee = mysqli_query($connection, $sqlemp);
						if (mysqli_num_rows($rs_employee) > 0){
							while ($row = mysqli_fetch_assoc($rs_employee)){
								$modFName = $row["emp_fname"];
								$modMName = $row["emp_midinit"];
								$modLName = $row["emp_lname"];
							}
							$MODNAME = $modFName . " " . $modMName . ". " . $modLName;
						}
						$sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'";
						$sqlmodupdate = "UPDATE modification set mod_name = '$MODNAME', mod_date = '$modDATE' WHERE mod_type = '$modTYPE'";
						$sqlmodinsert = "INSERT INTO modification VALUES ('$MODNAME', '$modDATE', '$modTYPE')";
						$rs_mod = mysqli_query($connection, $sqlmod);
						if(mysqli_num_rows($rs_mod) > 0){
							mysqli_query($connection, $sqlmodupdate);
						}
						else
						{
							mysqli_query($connection, $sqlmodinsert);
						}

				echo 	"<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Updated.</b>
						</td></tr>
						</table>
						</div>
					  </div>";
				header('Refresh:2; url=../admin/update-selectdesk.php');
			}
			else 
			{
				echo 	"<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Updating.</b>
						</td></tr></table></div>
						</div>";
				header('Refresh:2; url=../admin/update-selectdesk.php');
			}							
		}
		else
		{
			$selected = $_POST['desk_hname'];
			echo "
			<div class='container1'>
			<div class='addcontainer'>
			<fieldset>
			<table align='center'>
			<form method='POST'  action=''>
			<tr>
				<td>&nbsp;&nbsp;Selected hostname: $selected</td>
			</tr>
			<tr>
				<td>&nbsp;&nbsp;Input information:</td>
			</tr>
			";
			$sql1 = "SELECT * FROM desktop WHERE desk_hname = '".$selected."'";
			$result1 = mysqli_query($connection, $sql1);
			if(!$result1)
			{
				echo mysqli_error($connection);
			}
			elseif (mysqli_num_rows($result1) > 0) 
			{
				while ($row = mysqli_fetch_assoc($result1))
				{
					echo "
					<tr>
						<td>
							<input style='width: 224px;' class='input1' type='hidden' name='desk_hname' value='$row[desk_hname]' placeholder='Hostname'>
						</td>
					</tr>
					<tr>
						<td>
							<input style='width: 224px;' class='input1' type='text' name='desk_mb' value='$row[desk_mb]' placeholder='MotherBoard'>
							<input style='width: 224px;' class='input1' type='text' name='desk_processor' value='$row[desk_processor]' placeholder='Processor'>
						</td>
					</tr>
					<tr>
						<td><input style='width: 224px;' class='input1' type='text' name='desk_ram' value='$row[desk_ram]' placeholder='RAM'>
							<input style='width: 224px;' class='input1' type='text' name='desk_hd' value='$row[desk_hd]' placeholder='Hard Drive'></td>
					</tr>
					<tr>
						<td><input style='width: 224px;' class='input1' type='text' name='desk_monitor_p' value='$row[desk_monitor_p]' placeholder='Monitor (Primary)'>
							<input style='width: 224px;' class='input1' type='text' name='desk_monitor_s' value='$row[desk_monitor_s]' placeholder='Monitor (Secondary)'></td>
					</tr>
					<tr>
						<td><input style='width: 80px;' class='input1' type='text' name='desk_type' value='$row[desk_type]' placeholder='Type'>
							<input style='width: 180px;' class='input1' type='text' name='desk_kb' value='$row[desk_kb]' placeholder='Keyboard'>
							<input style='width: 144px;' class='input1' type='text' name='desk_mouse' value='$row[desk_mouse]' placeholder='Mouse'></td>
					</tr>
					<tr>
						<td><input style='width: 224px;' class='input1' type='text' name='desk_monitor_p' value='$row[desk_monitor_p]' placeholder='Monitor (Primary)'>
							<input style='width: 224px;' class='input1' type='text' name='desk_monitor_s' value='$row[desk_monitor_s]' placeholder='Monitor (Secondary)'></td>
					</tr>
					<tr>
						<td><input style='width: 224px;' class='input1' type='text' name='desk_os' value='$row[desk_os]' placeholder='Monitor (Primary)'>
							<input style='width: 224px;' class='input1' type='text' name='desk_ms' value='$row[desk_ms]' placeholder='Monitor (Secondary)'></td>
					</tr>
					<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='desk_dept' value=''>
							<option selected value=''>Currently selected: $row[desk_dept]</option>
							<option value='ABMP / FO'>ABMP / FO</option>
							<option value='ACCOUNTING'>ACCOUNTING</option>
							<option value='BILLING'>BILLING</option>
							<option value='CONSOLTANT'>CONSOLTANT</option>
							<option value='CRM DEV'>CRM DEV</option>
							<option value='DAVAO'>DAVAO</option>
							<option value='DESIGNER'>DESIGNER</option>
							<option value='EDITOR'>EDITOR</option>
							<option value='EVENTS'>EVENTS</option>
							<option value='FINANCE'>FINANCE</option>
							<option value='FO'>FO</option>
							<option value='HR'>HR</option>
							<option value='IT'>IT</option>
							<option value='IT MANAGER'>IT MANAGER</option>
							<option value='MARKETING M.'>MARKETING</option>
							<option value='PDEV'>PDEV</option>
							<option value='QA'>QA</option>
							<option value='SALES'>SALES</option>
							<option value='SALES MANAGER'>SALES MANAGER</option>
							<option value='SEO'>SEO</option>
							<option value='TECH ASS'>TECH ASS</option>
							<option value='TL PROD'>TL PROD</option>
							<option value='WEB DEV'>WEB DEV</option>
							<option value='WRITER'>WRITER</option>
						</select>
					</td>
				</tr>
					<tr>
						<td>
							<select class='input1' 
								style='color: black;
								padding-left:10px;
								margin: 10px;
								margin-top: 12px;
								margin-left: 18px;
								width: 505px;
								height: 35px;
								border: 1px solid #c7d0d2;
								border-radius: 2px;
								box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
								-webkit-transition: all .4s ease;
								-moz-transition: all .4s ease;
								transition: all .4s ease;
								transition: all .4s ease;' 
								name='desk_space' value=''>
								<option selected value=''>Currently selected: $row[desk_space]</option>
								<option value='EXPANSION'>EXPANSION</option>
								<option value='OLD OPS'>OLD OPS</option>
								<option value='SERVER ROOM'>SERVER ROOM</option>
							</select>
						</td>
					</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='desk_stat' value=''>
							<option selected value=''><b>STATUS</b></option>
							<option value='ACTIVE'>ACTIVE</option>
							<option value='FOR REPAIR'>FOR REPAIR</option>
							<option value='SPARE'>SPARE</option>
							<option value='DEFECTIVE / FOR DISPOSAL'>DEFECTIVE / FOR DISPOSA</option>
						</select>
					</td>
				</tr>
					<tr>
						<td><input style='width: 448px;' class='input1' type='text' name='desk_remarks' value='$row[desk_remarks]' placeholder='Remarks'></td>
					</tr>
					";
				}
			}
			echo "<tr>
				<td style='padding-left:20px;'><input style='padding-right:170px; padding-left:187px;' class='btn' type='submit' name='updatedesk' value='Update Desktop'></td>
			</tr>
			</form>
			</table>
		</fieldset>
		</div>
	</div>";
	mysqli_close($connection);
	}
	?>
	<br/><br/>
		<center class='input1'><a href="../admin/update-selectdesk.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>


