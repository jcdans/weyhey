<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<br/><br/>
	<div class="wrapper">
		<div class="container1">
			<div class="change">
				<table align="center">
					<tr>
						<br/>
						<td style="padding-left:50px;"><img src="../logo.png" height="125px" width="125px"></td>
					</tr>
				</table>
				<table align="center">
					<form method="POST" action="">
					<tr>
						<td>
						<?php
						include '../connection.php';
						if(!$connection) 
						{ 
							die('Connection Failed: ' . mysqli_connect_error());
						}		
						$sql = "SELECT emp_user FROM employee WHERE emp_type = 'USER'";
						$result = mysqli_query($connection, $sql);
						if(!$result)
						{
							echo mysqli_error($connection);
						}
						elseif (mysqli_num_rows($result) > 0) 
						{
							while($row = mysqli_fetch_assoc($result)) 
							{
								echo "<select class='input1' 
								style='color: black;
								padding-left:10px;
								margin: 10px;
								margin-top: 12px;
								margin-left: 18px;
								width: 260px;
								height: 35px;
								border: 1px solid #c7d0d2;
								border-radius: 2px;
								box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
								-webkit-transition: all .4s ease;
								-moz-transition: all .4s ease;
								transition: all .4s ease;
								transition: all .4s ease;' 
								name='emp_user' value=' ' required>"; 
								echo "<option value=''>SELECT USERNAME</option>";
								foreach($result as $value)
								{
									$emp = $value['emp_user'];
									echo "<option value='{$value['emp_user']}'>{$emp}</option>"; 
								} 
								echo "</select>"; 
								
							}
						}
						else 
						{
							echo "<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 260px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='emp_user' value=' ' required>"; 
							echo  "<option value=''>No Employee Added</option>
							  </select>";
						}
							mysqli_close($connection);							
						?>
						</td>
					</tr>
					<tr>
						<td><input class='input1' type='password' name='emp_new_pword1' placeholder='Enter New Password' required/></td>
					</tr>
					<tr>
						<td><input class='input1' type='password' name='emp_new_pword2' placeholder='Confirm Password' required/></td>
					</tr>
					<tr>
						<td style='padding-left:16px;'><input class='btn' style='padding-left:50px; padding-right:50px;'type='submit' name='change' value='Change Password'></td>  
					</tr>
					<tr>
						<td><?php
							if(isset($_POST['change']))
							{	
								include '../connection.php';
								
								$username = $_POST['emp_user'];
								$emp_new_pword1 = trim($_POST['emp_new_pword1']);
								$emp_new_pword2 = trim($_POST['emp_new_pword2']);
								
								if(!$connection) 
								{ 
									die('Connection Failed: ' . mysqli_connect_error());
								}

								$sql1 = "SELECT emp_user FROM employee WHERE emp_user = '$username'";
								$result1 = mysqli_query($connection, $sql1);

								if(mysqli_fetch_row($result1) > 0)
								{
									if($emp_new_pword1 == $emp_new_pword2)
									{	
										$sql2 = "UPDATE employee SET emp_pass = '$emp_new_pword2' WHERE emp_user = '$username'";
										
										if (mysqli_query($connection, $sql2))
										{
											echo "<table align='center'>
												<tr>
													<td><b class='b1' style='color:blue;'>Password has changed! Login now!</b></td>
												</tr>
											</table>
											<br/><br/>
											<center><a href='../admin/mainpage.php' class='input1'>Back</a></center>";
											exit;
										}
									}
									else 
									{
										echo "<table align='center'>
												<tr>
													<td><b class='b1'>Password does not match the confirm password.</b></td>
												</tr>
											</table>";
									}
								}
								else
								{
									echo "<table align='center'>
												<tr>
													<td><b class='b1'>Username not found in database.</b></td>
												</tr>
											</table>";
								}
								mysqli_close($connection);
							}
						?></td>
					</tr>
					</form>
				</table>			
			</div>
		</div>
		<br/><br/>
		<center><a href="../admin/mainpage.php" class="input1">Back</a></center>
		<div class="container1">
			<br/><br/><br/><br/><br/>
			<br/><br/><br/><br/><br/>
			<br/><br/><br/><br/><br/>
		</div>
		<footer>
			<div class="container1">
			<table align="left">
			<tr>
				<td style="padding-top:20px"><img src="../logo1-footer.png"></td>
			</tr>
			</table>
			<table align="center">
				<tr>
					<td>
						<ul class="ul3">
							<li><i><a href="log.php">Recent Logs</a></i></li>
							<li><a href="desktop.php">Desktop</a></li>
							<li><a href="headset.php">Headset</a></li>
							<li><a href="laptop.php">Laptop</a></li>
							<li><a href="spare.php">Spare</a></li>
							<li><a href="emp.php">Employee</a></li>
						</ul>
					</td>
				</tr>
				<tr>
					<td></td>
				</tr>
				<tr style="float:left;">
					<td><ul class="ul4" style="float:left;">
							<li><a style="color:white; font-weight:bold;">DESKTOP</a></li>
							<li><a href="adddesk.php" style="font-size:12px; color:darkgray;">Add Desktop</a></li>
							<li><a href="updatedesk.php" style="font-size:12px; color:darkgray;">Update Desktop</a></li>
							<li><a href="deldesk.php" style="font-size:12px; color:darkgray;">Delete Desktop</a></li>
						</ul></td>
					<td><ul class="ul4" style="float:left;">
							<li><a style="color:white; font-weight:bold;">HEADSET</a></li>
							<li><a href="addhead.php" style="font-size:12px; color:darkgray;">Add Headset</a></li>
							<li><a href="updatehead.php" style="font-size:12px; color:darkgray;">Update Headset</a></li>
							<li><a href="delhead.php" style="font-size:12px; color:darkgray;">Delete Headset</a></li>
						</ul></td>
					<td><ul class="ul4" style="float:left;">
							<li><a style="color:white; font-weight:bold;">LAPTOP</a></li>
							<li><a href="addlap.php" style="font-size:12px; color:darkgray;">Add Laptop</a></li>
							<li><a href="updatelap.php" style="font-size:12px; color:darkgray;">Update Laptop</a></li>
							<li><a href="dellap.php" style="font-size:12px; color:darkgray;">Delete Laptop</a></li>
						</ul></td>
					<td><ul class="ul4" style="float:left;">
							<li><a style="color:white; font-weight:bold;">SPARE</a></li>
							<li><a href="addspare.php" style="font-size:12px; color:darkgray;">Add Spare</a></li>
							<li><a href="updatespare.php" style="font-size:12px; color:darkgray;">Update Spare</a></li>
							<li><a href="delspare.php" style="font-size:12px; color:darkgray;">Delete Spare</a></li>
						</ul></td>
					<td><ul class="ul4" style="float:left;">
							<li><a style="color:white; font-weight:bold;">EMPLOYEE</a></li>
							<li><a href="emp.php" style="font-size:12px; color:darkgray;">Show Employees</a></li>
						</ul></td>
				</tr>
				<tr>
					<td><br/></td>
				</tr>
				<tr>
					<td><br/></td>
				</tr>
				<tr>
					<td><br/></td>
				</tr>
				<tr>
					<td><br/></td>
				</tr>
			</table>
			</div>
		</footer>
		<footer class="footer2">
			<div class="container1">
				<table>
					<tr>
						<td><span>Copyright © 2016-2017 Commercial Reach Inc. All rights reserved.</span></td>
					</tr>
				</table>
			</div>
		</footer>
		</div>
	</body>
</html>