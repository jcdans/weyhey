<div class="container1">
	<br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
	<br/><br/>
</div>
<footer>
	<div class="container1">
	<table align="left">
	<tr>
		<td style="padding-top:20px"><img src="../logo1-footer.png"></td>
	</tr>
	</table>
	<table align="center">
		<tr>
			<td>
				<ul class="ul3">
					<li><i><a href="log.php">Recent Logs</a></i></li>
					<li><a href="desktop.php">Desktop</a></li>
					<li><a href="headset.php">Headset</a></li>
					<li><a href="laptop.php">Laptop</a></li>
					<li><a href="emp.php">Employee</a></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td></td>
		</tr>
		<tr style="float:left;">
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">DESKTOP</a></li>
					<li><a href="adddesk.php" style="font-size:12px; color:darkgray;">Add Desktop</a></li>
					<li><a href="update-selectdesk.php" style="font-size:12px; color:darkgray;">Update Desktop</a></li>
					<li><a href="deldesk.php" style="font-size:12px; color:darkgray;">Delete Desktop</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">HEADSET</a></li>
					<li><a href="addhead.php" style="font-size:12px; color:darkgray;">Add Headset</a></li>
					<li><a href="update-selecthead.php" style="font-size:12px; color:darkgray;">Update Headset</a></li>
					<li><a href="delhead.php" style="font-size:12px; color:darkgray;">Delete Headset</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">LAPTOP</a></li>
					<li><a href="addlap.php" style="font-size:12px; color:darkgray;">Add Laptop</a></li>
					<li><a href="update-selectlap.php" style="font-size:12px; color:darkgray;">Update Laptop</a></li>
					<li><a href="dellap.php" style="font-size:12px; color:darkgray;">Delete Laptop</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">SPARE</a></li>
					<li><a href="addspare.php" style="font-size:12px; color:darkgray;">Add Spare</a></li>
					<li><a href="update-selectspare.php" style="font-size:12px; color:darkgray;">Update Spare</a></li>
					<li><a href="delspare.php" style="font-size:12px; color:darkgray;">Delete Spare</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">EMPLOYEE</a></li>
					<li><a href="emp.php" style="font-size:12px; color:darkgray;">Show Employees</a></li>
				</ul></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
	</table>
	</div>
</footer>
<footer class="footer2">
	<div class="container1">
		<table>
			<tr>
				<td><span>Copyright © 2016-2017 Willver de Jesus, and Commercial Reach Inc. All rights reserved.</span></td>
			</tr>
		</table>
	</div>
</footer>
</div>
