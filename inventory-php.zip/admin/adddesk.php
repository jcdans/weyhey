<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['adddesk']))
			{
				include '../connection.php';
				
				$desk_row = $_POST['desk_row'];
				$desk_hname = $_POST['desk_hname'];
				$desk_mb = $_POST['desk_mb'];
				$desk_processor = $_POST['desk_processor'];
				$desk_ram = $_POST['desk_ram'];
				$desk_hd = $_POST['desk_hd'];
				$desk_monitor_p = $_POST['desk_monitor_p'];
				$desk_monitor_s = $_POST['desk_monitor_s'];
				$desk_type = $_POST['desk_type'];
				$desk_kb = $_POST['desk_kb'];
				$desk_mouse = $_POST['desk_mouse'];
				$desk_os = $_POST['desk_os'];
				$desk_ms = $_POST['desk_ms'];
				$desk_dept = $_POST['desk_dept'];
				$desk_space = $_POST['desk_space'];
				$desk_remarks = $_POST['desk_remarks'];
				$desk_stat = $_POST['desk_stat'];
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = "INSERT INTO desktop (desk_row, desk_hname, desk_mb, desk_processor, desk_ram, desk_hd, desk_monitor_p, desk_monitor_s, desk_type, desk_kb, desk_mouse, desk_os, desk_ms, desk_dept, desk_space, desk_remarks, desk_stat) 
						VALUES ('$desk_row', '$desk_hname', '$desk_mb', '$desk_processor', '$desk_ram', '$desk_hd', '$desk_monitor_p', '$desk_monitor_s', '$desk_type', '$desk_kb', '$desk_mouse', '$desk_os', '$desk_ms', '$desk_dept', '$desk_space', '$desk_remarks', '$desk_stat')";
						
				if(mysqli_multi_query($connection, $sql)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
				}							
			mysqli_close($connection);
			}
		?>
	</div>
	
	<br/><br/>
	<div class="container1">
		<div class="addcontainer">
			<fieldset>
			</table>
				<table align="center">
				<tr>
					<td>
						<form method="POST"  action="">
						<input style="width: 80px;" class="input1" type="text" name="desk_row" placeholder="Row No." autofocus>
						<input style="width: 180px;" class="input1" type="text" name="desk_hname" placeholder="Hostname" required>
						<input style="width: 144px;" class="input1" type="text" name="desk_mb" placeholder="MotherBoard">
					</td>
				</tr>
				<tr>
					<td>
						<input style="width: 224px;" class="input1" type="text" name="desk_processor" placeholder="Processor">
						<input style="width: 80px;" class="input1" type="text" name="desk_ram" placeholder="RAM">
						<input style="width: 100px;" class="input1" type="text" name="desk_hd" placeholder="Hard Drive">
					</td>
				</tr>
				<tr>
					<td><input style="width: 224px;" class="input1" type="text" name="desk_monitor_p" placeholder="Monitor (Primary)">
						<input style="width: 224px;" class="input1" type="text" name="desk_monitor_s" placeholder="Monitor (Secondary)"></td>
				</tr>
				<tr>
					<td><input style="width: 80px;" class="input1" type="text" name="desk_type" placeholder="Type">
						<input style="width: 180px;" class="input1" type="text" name="desk_kb" placeholder="Keyboard">
						<input style="width: 144px;" class="input1" type="text" name="desk_mouse" placeholder="Mouse"></td>
				</tr>
				<tr>
					<td><input style="width: 224px;" class="input1" type="text" name="desk_os" placeholder="Operating System">
						<input style="width: 224px;" class="input1" type="text" name="desk_ms" placeholder="Microsoft Office"></td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='desk_dept' value=''>
							<option selected value=""><b>DEPARTMENT</b></option>
							<option value="ABMP / FO">ABMP / FO</option>
							<option value="ACCOUNTING">ACCOUNTING</option>
							<option value="BILLING">BILLING</option>
							<option value="CONSOLTANT">CONSOLTANT</option>
							<option value="CRM DEV">CRM DEV</option>
							<option value="DAVAO">DAVAO</option>
							<option value="DESIGNER">DESIGNER</option>
							<option value="EDITOR">EDITOR</option>
							<option value="EVENTS">EVENTS</option>
							<option value="FINANCE">FINANCE</option>
							<option value="FO">FO</option>
							<option value="HR">HR</option>
							<option value="IT">IT</option>
							<option value="IT MANAGER">IT MANAGER</option>
							<option value="MARKETING M.">MARKETING</option>
							<option value="PDEV">PDEV</option>
							<option value="QA">QA</option>
							<option value="SALES">SALES</option>
							<option value="SALES MANAGER">SALES MANAGER</option>
							<option value="SEO">SEO</option>
							<option value="TECH ASS">TECH ASS</option>
							<option value="TL PROD">TL PROD</option>
							<option value="WEB DEV">WEB DEV</option>
							<option value="WRITER">WRITER</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='desk_space' value=''>
							<option selected value=""><b>DEPLOYED LOCATION</b></option>
							<option value="EXPANSION">EXPANSION</option>
							<option value="OLD OPS">OLD OPS</option>
							<option value="SERVER ROOM">SERVER ROOM</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<input style="width: 493px;" class="input1" type="text" name="desk_remarks" placeholder="Remarks">
					</td>
				</tr>				
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='desk_stat' value=''>
							<option selected value=""><b>STATUS</b></option>
							<option value="ACTIVE">ACTIVE</option>
							<option value="FOR REPAIR">FOR REPAIR</option>
							<option value="SPARE">SPARE</option>
							<option value="DEFECTIVE / FOR DISPOSAL">DEFECTIVE / FOR DISPOSA</option>
						</select>
					</td>
				</tr>
				<tr>
					<td style="padding-left:20px;"><input style="padding-right:192px; padding-left:192px;" class="btn" type="submit" name="adddesk" value="Add Desktop"></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>