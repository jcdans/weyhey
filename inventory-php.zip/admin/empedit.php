<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<div class="headerconfirm">
		<?php
			include '../connection.php';
			if(isset($_POST['empedit']))
			{
				$username = $_SESSION['username'];
				$emp_pass = $_POST['emp_pass'];
				$emp_fname = $_POST['emp_fname'];
				$emp_lname = $_POST['emp_lname'];
				$emp_midinit = $_POST['emp_midinit'];
				$emp_address = $_POST['emp_address'];
				$emp_bday = $_POST['emp_bday'];
				$emp_cellnum = $_POST['emp_cellnum'];
				$emp_email = $_POST['emp_email'];
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = '';
				if(!empty($emp_pass))
					$sql .= "`emp_pass` = '$emp_pass',";
				if(!empty($emp_fname))
					$sql .= "`emp_fname` = '$emp_fname',";
				if(!empty($emp_lname))
					$sql .= "`emp_lname` = '$emp_lname',";
				if(!empty($emp_midinit))
					$sql .= "`emp_midinit` = '$emp_midinit',";
				if(!empty($emp_address))
					$sql .= "`emp_address` = '$emp_address',";
				if(!empty($emp_bday))
					$sql .= "`emp_bday` = '$emp_bday',";
				if(!empty($emp_cellnum))
					$sql .= "`emp_cellnum` = '$emp_cellnum',";
				if(!empty($emp_email))
					$sql .= "`emp_email` = '$emp_email',";
				$sql = trim($sql,',');

				if(!empty($sql))
				{
					$sql4 = "UPDATE
					employee
					SET
					$sql
					WHERE
					emp_user = '$username'";
				}
						
				if(mysqli_multi_query($connection, $sql4)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
					header('Refresh:2; url=../admin/profile.php');
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
					header('Refresh:2; url=../admin/empedit.php');
				}							
			}
			else
			{
				$username = $_SESSION['username'];
				$sql = "SELECT * FROM employee WHERE emp_user LIKE '$username'";
				$result = mysqli_query($connection, $sql);
				while ($row = mysqli_fetch_assoc($result)) 
				{
	echo "
	</div>
	
	<br/><br/>
	<div class='container1'>
		<div class='addcontainer'>
			<fieldset>
			</table>
				<table align='center'>
				<tr>
					<td>
						<form method='POST'  action=''>
						<input style='width: 224px;' class='input1' type='text' name='emp_user' placeholder='Username' value='$row[emp_user]' disabled='true'>
						<input style='width: 224px;' class='input1' type='password' name='emp_pass' placeholder='Password' value='$row[emp_pass]' autofocus required>
					</td>
				</tr>
				<tr>
					<td>
						<input style='width: 144px;' class='input1' type='text' name='emp_fname' placeholder='First name' value='$row[emp_fname]'>
						<input style='width: 144px;' class='input1' type='text' name='emp_lname' placeholder='Last name' value='$row[emp_lname]'>
						<input style='width: 115px;' class='input1' type='text' name='emp_midinit' placeholder='Middle Initial' value='$row[emp_midinit]'>
					</td>
				</tr>
				<tr>
					<td><input style='width: 490px;' class='input1' type='text' name='emp_address' placeholder='Address' value='$row[emp_address]'>
					</td>
				</tr>
				<tr>
					<td><input style='width: 224px;' class='input1' type='date' name='emp_bday' value='$row[emp_bday]'>
						<input style='width: 224px;' class='input1' type='text' name='emp_cellnum' placeholder='Cellphone number' value='$row[emp_cellnum]'>
					</td>
				</tr>
				<tr>
					<td><input style='width: 490px;' class='input1' type='email' name='emp_email' placeholder='example@email.com' value='$row[emp_email]'>
					</td>
				</tr>
				<tr>
					<td style='padding-left:15px;'><input style='padding-right:228px; padding-left:235px;' class='btn' type='submit' name='empedit' value='Save'></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		";
				}
		mysqli_close($connection);
		}
		?>
		<br/><br/>
		<center class="input1"><a href="../admin/profile.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>