<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
		<?php
			$inserted = FALSE;
			session_start();
			include '../connection.php';
			include '../PHPExcel/IOFactory.php';
			
			$objPHPExcel = PHPExcel_IOFactory::load('desktop-inventory.xlsx');
			foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
			{
				$highestRow = $worksheet->getHighestRow();
				for ($row = 0; $row <= $highestRow; $row++)
				{
					$desk_row = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
					$desk_hname = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
					$desk_mb = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
					$desk_processor = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
					$desk_ram = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
					$desk_hd = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
					$desk_monitor_p = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(6, $row)->getValue());
					$desk_monitor_s = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(7, $row)->getValue());
					$desk_type = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(8, $row)->getValue());
					$desk_kb = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(9, $row)->getValue());
					$desk_mouse = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(10, $row)->getValue());
					$desk_os = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(11, $row)->getValue());
					$desk_ms = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(12, $row)->getValue());
					$desk_dept = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(13, $row)->getValue());
					$desk_space = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(14, $row)->getValue());
					$desk_remarks = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(15, $row)->getValue());
					$desk_stat = "ACTIVE";
						
					if ($desk_type != "" && $desk_type == "DESKTOP" || $desk_type == "LAPTOP")
					{
						$sql = "INSERT INTO desktop (desk_row, desk_hname, desk_mb, desk_processor, desk_ram, desk_hd, desk_monitor_p, desk_monitor_s, desk_type, desk_kb, desk_mouse, desk_os, desk_ms, desk_dept, desk_space, desk_remarks, desk_stat) 
								VALUES ('".$desk_row."', '".$desk_hname."', '".$desk_mb."', '".$desk_processor."', '".$desk_ram."', '".$desk_hd."', '".$desk_monitor_p."', '".$desk_monitor_s."', '".$desk_type."', '".$desk_kb."', '".$desk_mouse."', '".$desk_os."', '".$desk_ms."', '".$desk_dept."', '".$desk_space."', '".$desk_remarks."', '".$desk_stat."')";
						mysqli_query($connection, $sql);
						$inserted = TRUE;
					}

				}
			}
			if($inserted === TRUE){
						date_default_timezone_set('Asia/Manila');
						$modDATE = date('F d Y H:i:s.');
						$modTYPE = "Desktop";
						 if(!isset($_SESSION)){ 
						        session_start(); 
						} 
						$user = $_SESSION['username'];
						$pass = $_SESSION['userpass'];
						
						$sqlemp = "SELECT * FROM employee WHERE emp_user = '$user'"; 
						$rs_employee = mysqli_query($connection, $sqlemp);
						if (mysqli_num_rows($rs_employee) > 0){
							while ($row = mysqli_fetch_assoc($rs_employee)){
								$modFName = $row["emp_fname"];
								$modMName = $row["emp_midinit"];
								$modLName = $row["emp_lname"];
							}
							$MODNAME = $modFName . " " . $modMName . ". " . $modLName;
						}
						$sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'";
						$sqlmodupdate = "UPDATE modification set mod_name = '$MODNAME', mod_date = '$modDATE' WHERE mod_type = '$modTYPE'";
						$sqlmodinsert = "INSERT INTO modification VALUES ('$MODNAME', '$modDATE', '$modTYPE')";
						$rs_mod = mysqli_query($connection, $sqlmod);
						if(mysqli_num_rows($rs_mod) > 0){
							mysqli_query($connection, $sqlmodupdate);
						}
						else
						{
							mysqli_query($connection, $sqlmodinsert);
						}
			}
		?>
		<br/><br/><br/><br/><br/>
		<?php
		if($inserted){
		echo "
		<center class='input1'>Congratulations! Data inserted!</center>";
		}
		else{
			echo "
		<center class='input1'>Data insertion failed!</center>";
		}
		 header('Refresh:2; url=upload.php');?>
		
	</body>
</html>