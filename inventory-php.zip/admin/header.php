<?php ob_start(); 
//There are two other functions you typically pair 
//it with: ob_get_contents(), which basically gives 
//you whatever has been "saved" to the buffer since 
//it was turned on with ob_start(), and then ob_end_clean() 
//or ob_flush(), which either stops saving things and 
//discards whatever was saved, or stops saving and 
//outputs it all at once, respectively. ?> 
<div class="wrapper">
<header>
	<div class="container1">
		<table>
			<tr>
				<td style="padding:left:300px; padding-top:35px;"><a href="../admin/mainpage.php"><img src="../logo1.png" width="390px"></a></td>
				<td style="padding-left:500px"></td>
				<td>
				<?php
					 if(!isset($_SESSION)) 
					    { 
					        session_start(); 
					    } 
					$username = $_SESSION['username'].'▾';
					if($_SESSION['logged'] == true) 
					{ 
						if($_SESSION['emp_type'] == 'ADMIN')
						{
							echo "<ul id='nav'>
								<li><a class='fly' href='#' tabindex='1'>$username</a>
								<ul class='dd'>
									<li><a href='../admin/upload.php'><b class='b11'>Import file</b></a></li>
									<li><a href='../admin/download.php'><b class='b11'>Export file</b></a></li>
									<li><a href='../admin/newuser.php'><b class='b11'>Register new user/admin</b></a></li>
									<li><a href='../admin/delemp.php'><b class='b11'>Delete user/admin</b></a></li>
									<li><a href='../admin/changepass.php'><b class='b11'>Reset password for user</b></a></li>
									<li><a href='profile.php'><b class='b11'>Profile</b></a></li>
									<li><a href='logout.php'><b class='b11'>Logout</b></a></li>
								</ul>
								</li>
							</ul>";
						}
						else
						{
							header('Refresh:0; url=../admin/mainpage.php');
						}
					}
					else 
					{
						header('Refresh:0; url=/inventory-php');
					}
				?>
				</td>
			</tr>
		</table>
	</div>
</header>
<hr>
<table align = 'center'>
	<tr>
		<td>
			<ul id='nav'>
				<li><a class='fly' href='../admin/sum.php'><img src='../pics/btnSum.png' height='115px' width='115px'></a></li>
			</ul>
		</td>
		<td>
			<ul id='nav'>
				<li><a class='fly' href='../admin/log.php'><img src='../pics/btnLog.png' height='115px' width='115px'></a></li>
			</ul>
		</td>
		<td>
			<ul id='nav'>
			<?php 
			include "../connection.php";
			//include "../connect.php";
			
			mysqli_select_db($connection, "inventory");

			// DESKTOP

			$resultdesk1 = mysqli_query($connection, "SELECT * FROM desktop WHERE desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk1 = mysqli_num_rows($resultdesk1);

			//active
			$resultdesk2 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'ACTIVE' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk2 = mysqli_num_rows($resultdesk2);

			//for repair
			$resultdesk3 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'FOR REPAIR' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk3 = mysqli_num_rows($resultdesk3);

			//defective
			$resultdesk4 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'DEFECTIVE / FOR DISPOSAL' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk4 = mysqli_num_rows($resultdesk4);

			//spare
			$resultdesk5 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'SPARE' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk5 = mysqli_num_rows($resultdesk5);

			$desk = "A total of: $num_rowsdesk1 desktop(s)
Active: $num_rowsdesk2
For Repair: $num_rowsdesk3
Defective / For disposal: $num_rowsdesk4
Spare: $num_rowsdesk5
";

			echo "<li><a class='fly' href='#' tabindex='1' title='$desk'><img src='../pics/btnDesk.png' height='115px' width='115px'></a>";?>
				<ul class='dd' style="top:132px">
					<li><a href='../admin/desktop.php'><b class='b11'>Display desktops</b></a></li>
					<li><a href='../admin/adddesk.php'><b class='b11'>Register new desktop</b></a></li>
					<li><a href='../admin/deldesk.php'><b class='b11'>Delete desktop</b></a></li>
					<li><a href='../admin/update-selectdesk.php'><b class='b11'>Update desktop</b></a></li>							
				</ul>
				</li>
			</ul>
		</td>
		<td>
			<ul id='nav'>
			<?php 
			include "../connection.php";
			
			mysqli_select_db($connection, "inventory");

			// HEADSET

			$resulthead1 = mysqli_query($connection, "SELECT * FROM headset");
			$num_rowshead1 = mysqli_num_rows($resulthead1);

			//active
			$resulthead2 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'ACTIVE'");
			$num_rowshead2 = mysqli_num_rows($resulthead2);

			//missing
			$resulthead3 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'MISSING'");
			$num_rowshead3 = mysqli_num_rows($resulthead3);

			//for repair
			$resulthead4 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'FOR REPAIR'");
			$num_rowshead4 = mysqli_num_rows($resulthead4);

			//defective
			$resulthead5 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'DEFECTIVE / FOR DISPOSAL'");
			$num_rowshead5 = mysqli_num_rows($resulthead5);

			//spare
			$resulthead6 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'SPARE'");
			$num_rowshead6 = mysqli_num_rows($resulthead6);

			$head = "A total of: $num_rowshead1 headset(s)
Active: $num_rowshead2
Missing: $num_rowshead3
For Repair: $num_rowshead4
Defective / For disposal: $num_rowshead5
Spare: $num_rowshead6
			";
				echo "<li><a class='fly' href='#' tabindex='1' title='$head'><img src='../pics/btnHead.png' height='115px' width='115px'></a>";?>
				<ul class='dd' style="top:132px">
					<li><a href='../admin/headset.php'><b class='b11'>Display headsets</b></a></li>
					<li><a href='../admin/addhead.php'><b class='b11'>Register new headset</b></a></li>
					<li><a href='../admin/delhead.php'><b class='b11'>Delete headset</b></a></li>
					<li><a href='../admin/update-selecthead.php'><b class='b11'>Update headset</b></a></li>
				</ul>
				</li>
			</ul>
		</td>
		<td>
			<ul id='nav'>
			<?php 
			include "../connection.php";
			
			mysqli_select_db($connection, "inventory");

			// LAPTOP

			$resultlap1 = mysqli_query($connection, "SELECT * FROM laptop");
			$num_rowslap1 = mysqli_num_rows($resultlap1);

			//active
			$resultlap2 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'ACTIVE'");
			$num_rowslap2 = mysqli_num_rows($resultlap2);

			//for repair
			$resultlap3 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'FOR REPAIR'");
			$num_rowslap3 = mysqli_num_rows($resultlap3);

			//defective
			$resultlap4 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'DEFECTIVE / FOR DISPOSAL'");
			$num_rowslap4 = mysqli_num_rows($resultlap4);

			//spare
			$resultlap5 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'SPARE'");
			$num_rowslap5 = mysqli_num_rows($resultlap5);

			$lap = "A total of: $num_rowslap1 laptop(s)
Active: $num_rowslap2
For Repair: $num_rowslap3
Defective / For disposal: $num_rowslap4
Spare: $num_rowslap5
			";
			echo "<li><a class='fly' href='#' tabindex='1' title='$lap'><img src='../pics/btnLap.png' height='115px' width='115px'></a>";?>
				<ul class='dd' style="top:132px">
					<li><a href='../admin/laptop.php'><b class='b11'>Display laptops</b></a></li>
					<li><a href='../admin/addlap.php'><b class='b11'>Register new laptop</b></a></li>
					<li><a href='../admin/dellap.php'><b class='b11'>Delete laptop</b></a></li>
					<li><a href='../admin/update-selectlap.php'><b class='b11'>Update laptop</b></a></li>
				</ul>
				</li>
			</ul>
		</td>
		<td>
			<ul id='nav'>
			<?php 
			include "../connection.php";
			
			mysqli_select_db($connection, "inventory");

			// SPARE

			//monitor
			$resultspare2 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'MONITOR'");
			$num_rowsspare2 = mysqli_num_rows($resultspare2);

			//keyboard
			$resultspare3 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'KEYBOARD'");
			$num_rowsspare3 = mysqli_num_rows($resultspare3);

			//mouse
			$resultspare4 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'MOUSE'");
			$num_rowsspare4 = mysqli_num_rows($resultspare4);

			//processor
			$resultspare5 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'RAM'");
			$num_rowsspare5 = mysqli_num_rows($resultspare5);

			//processor
			$resultspare6 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'PROCESSOR'");
			$num_rowsspare6 = mysqli_num_rows($resultspare6);

			$spare = "Monitor: $num_rowsspare2
Keyboard: $num_rowsspare3
Mouse: $num_rowsspare4
RAM: $num_rowsspare5
Processor: $num_rowsspare6
			";
			echo "<li><a class='fly' href='#' tabindex='1' title='$spare'><img src='../pics/btnSpare.png' height='115px' width='115px'></a>";?>
				<ul class='dd' style="top:132px">
					<li><a href='../admin/spare.php'><b class='b11'>Display spares</b></a></li>
					<li><a href='../admin/addspare.php'><b class='b11'>Register new spare</b></a></li>
					<li><a href='../admin/delspare.php'><b class='b11'>Delete spare</b></a></li>
					<li><a href='../admin/update-selectspare.php'><b class='b11'>Update spare</b></a></li>
				</ul>
				</li>
			</ul>
		</td>
	</tr>
</table>