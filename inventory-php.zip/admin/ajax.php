<?php
			        echo "<select id='select2' name='filtermb' required>";
			       
			        	echo "<option value=''>-- $select -- </option>";
			        	if(!empty($_GET['city']){
			        		
							$sql = "SELECT distinct * FROM desktop GROUP BY desk_mb ORDER BY convert('desk_mb', int) "; 
							$resultproc = mysqli_query($connection, $sql);
							

							 echo "<option value=''>-- select one -- </option>";
							while($rows = mysqli_fetch_assoc($resultproc)){
								if($rows[desk_mb]!=null)
								  echo "<option value='$rows[desk_mb]'>$rows[desk_mb]</option>";
							}
							
						}

					  
					echo "</select>";
 ?>