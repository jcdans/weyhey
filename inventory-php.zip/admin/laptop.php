<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
		<table align = "center">
			<tr>
				<td style="padding-left:670px"><form action="searchlap.php" method="post">
				<a class="input1">Filter Search:</a>
				<select name="filter" required>
						<option value="">Choose filter option</option>
		                <option value="row">Row</option>
		                <option value="hostname">Hostname</option>
		                <option value="serial">Serial No.</option>
		                <option value="model">Model</option>
		                <option value="processor">Processor</option>
		                <option value="ram">Ram</option>
		                <option value="hd">HD</option>
		                <option value="type">Type</option>
		                <option value="os">Operating System</option>
		                <option value="ms">Microsoft Office</option>
		                <option value="dept">Department</option>
		                <option value="space">Space</option> 
		                <option value="remarks">User/Remarks</option>  	            
			        </select>
					<input style="width: 180px;" class="input1" type="text" name="search" placeholder="Search (eg. hostname)" autofocus>
					<input type="submit" name="submitSearch" value="Search">
				</form>
				</td>
			</tr>
		</table>
		<h3 style="text-align: center;">LAPTOP</h3>
		<div class="container1">
		<section>
		<?php
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM laptop ORDER BY convert('lap_row', int), convert('lap_host', int) LIMIT $start_from, $num_rec_per_page";
			$rs_result = mysqli_query($connection, $sql); //run the query
			
			if (mysqli_num_rows($rs_result) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
	
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>Row</th>
				<th>Hostname</th>
				<th>Serial No.</th>
				<th>Model</th>
				<th>Processor</th>
				<th>RAM</th>
				<th>HD</th>
				<th>Type</th>
				<th>Operating System</th>
				<th>Microsoft Office</th>
				<th>Department</th>
				<th>Space</th>
				<th>User/Remarks</th>
				</tr>";		
		
				while ($row = mysqli_fetch_assoc($rs_result)) 
				{
					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_row]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a title='$row[lap_space]' value='$row[lap_host]'>$row[lap_host]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_serial]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_model]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_processor]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_ram]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_hd]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_type]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_os]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_ms]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_dept]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_space]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[lap_host]'>$row[lap_user_remarks]</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					</section>";
				
				$sql1 = "SELECT * FROM laptop"; 

					$rs_result = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($rs_result);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<section> <a href='laptop.php?page=1'>".'First'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='laptop.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='laptop.php?page=$total_pages'>".'Last'."</a> "; // Goto last page
		}		
		else 
		{
			echo "
			<table align:left>
				<tr>
					<td>No laptops found.</td>
				</tr>
			</table>";
		}	
		?>	
		</section>
		</div>
		<br/><br/>
		<table align = "center">
		<tr>
			<td class="input1">
			<?php
			 $modTYPE = "Laptop";
			 $sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'"; 
						$rs_modification = mysqli_query($connection, $sqlmod);
						if (mysqli_num_rows($rs_modification) > 0){
							while ($row = mysqli_fetch_assoc($rs_modification)){
								$modName = $row["mod_name"];
								$modDate = $row["mod_date"];
							}
							echo "Last modified: " . $modDate . " By: " .$modName;
						}

			

			?>
			</td>
		</tr>
		<tr>
			<td align = "center" class='input1'><br/><br/><br/><a href='../admin/mainpage.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>