<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['updatehead']))
			{
				include '../connection.php';
				
				$hs_num = $_POST['hs_num'];
				$hs_brand = $_POST['hs_brand'];
				$hs_model = ($_POST['hs_model']);
				//$hs_serial = ($_POST['hs_serial']);
				$hs_type = ($_POST['hs_type']);
				$hs_status = ($_POST['hs_status']);
				$hs_avail = $_POST['hs_avail'];	
				$hs_release_to_real = $_POST['hs_release_to_real'];
				$hs_release_to_phone = $_POST['hs_release_to_phone'];
				$hs_release_date = $_POST['hs_release_date'];
				$hs_return_date = $_POST['hs_return_date'];
				$hs_release_by = $_POST['hs_release_by'];
				$hs_dept = $_POST['hs_dept'];
				$hs_space = $_POST['hs_space'];
				$hs_remarks = $_POST['hs_remarks'];				
				$hs_stat = $_POST['hs_stat'];
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = '';
				if(!empty($hs_brand))
					$sql .= "`hs_brand` = '$hs_brand',";
				if(!empty($hs_model))
					$sql .= "`hs_model` = '$hs_model',";
				//if(!empty($hs_serial))
				//	$sql .= "`hs_serial` = '$hs_serial',";
				if(!empty($hs_serial))
					$sql .= "`hs_serial` = '$hs_serial',";
				if(!empty($hs_type))
					$sql .= "`hs_type` = '$hs_type',";
				if(!empty($hs_status))
					$sql .= "`hs_status` = '$hs_status',";
				if(!empty($hs_avail))
					$sql .= "`hs_avail` = '$hs_avail',";
				if(!empty($hs_release_to_real))
					$sql .= "`hs_release_to_real` = '$hs_release_to_real',";
				if(!empty($hs_release_to_phone))
					$sql .= "`hs_release_to_phone` = '$hs_release_to_phone',";
				if(!empty($hs_release_date))
					$sql .= "`hs_release_date` = '$hs_release_date',";
				if(!empty($hs_return_date))
					$sql .= "`hs_return_date` = '$hs_return_date',";
				if(!empty($hs_release_by))
					$sql .= "`hs_release_by` = '$hs_release_by',";
				if(!empty($hs_dept))
					$sql .= "`hs_dept` = '$hs_dept',";
				if(!empty($hs_space))
					$sql .= "`hs_space` = '$hs_space',";
				if(!empty($hs_remarks))
					$sql .= "`hs_remarks` = '$hs_remarks',";
				if(!empty($hs_stat))
					$sql .= "`hs_stat` = '$hs_stat',";
				$sql = trim($sql,',');

				if(!empty($sql))
				{
					$sql4 = "UPDATE
					headset
					SET
					$sql
					WHERE
					hs_num = '$hs_num'";
				}
				if(mysqli_query($connection, $sql4)) 
				{	
					echo 	"<div class='headerconfirm' style='background-color:#47a3da;'>
							<div class='container1'>
							<table align='center'>
							<tr>
							<td>
							<b class='b7'>Successfully Updated.</b>
							</td></tr>
							</table>
							</div>
						  </div>";
					header('Refresh:2; url=../admin/update-selecthead.php');
				}
				else 
				{
					echo 	"<div class='headerconfirm' style='background-color:red;'>
							<div class='container1'>
							<table align='center'>
							<tr>
							<td>
							<b class='b7'>Error in Updating.</b>
							</td></tr></table></div>
							</div>";
					header('Refresh:2; url=../admin/update-selecthead.php');
				}
			}
			else
			{
				$selected = $_POST['hs_num'];
	echo "
	</div>

	<br/><br/>
	<div class='container1'>
		<div class='addcontainer'>
			<fieldset>
				<table align='center'>
				<form method='POST'  action=''>
				<tr>
					<td>&nbsp;&nbsp;Selected hostname: $selected</td>
				</tr>
				<tr>
					<td>&nbsp;&nbsp;Input information:</td>
				</tr>";
				$sql1 = "SELECT * FROM headset WHERE hs_num = '".$selected."'";
				$result1 = mysqli_query($connection, $sql1);
				if(!$result1)
				{
					echo mysqli_error($connection);
				}
				elseif (mysqli_num_rows($result1) > 0) 
				{
					while ($row = mysqli_fetch_assoc($result1))
					{
					echo "
				<tr>
					<td>
						<input style='width: 224px;' class='input1' type='hidden' name='hs_num' value='$row[hs_num]' placeholder='Headset Number'>
					</td>
				</tr>
				<tr>
					<td><input style='width: 135px;' class='input1' type='text' name='hs_brand' value='$row[hs_brand]' placeholder='Brand' autofocus>
						<input style='width: 135px;' class='input1' type='text' name='hs_model' value='$row[hs_model]' placeholder='Model'>
						<input style='width: 135px;' class='input1' type='text' name='hs_type' value='$row[hs_type]' placeholder='Type'>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_status' value=''>
							<option selected value=''>Currently selected: $row[hs_status]</option>
							<option value='NEW'>NEW</option>
							<option value='OLD'>OLD</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_avail' value=''>
							<option selected value=''>Currently selected: $row[hs_avail]</option>
							<option value='AC'>ACTIVE</option>
							<option value='FR'>FOR REPAIR</option>
							<option value='MS'>MISSING</option>
							<option value='TP'>TEMPORARY</option>
							<option value='DE'>DEFECTIVE / FOR DISPOSAL</option>
							<option value='SP'>SPARE</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<form method='POST'  action=''>
						<input style='width: 160px;' class='input1' type='text' name='hs_release_to_real' value='$row[hs_release_to_real]' placeholder='Released to (real name)'>
						<input style='width: 160px;' class='input1' type='text' name='hs_release_to_phone' value='$row[hs_release_to_phone]' placeholder='(phone name)'>
						<input style='width: 94px;' class='input1' type='text' name='hs_release_by' value='$row[hs_release_by]' placeholder='Released by'>
					</td>
				</tr>
				<tr>
					<td style='padding-left:12px'>
						Release date:<input style='width: 140px;' class='input1' type='text' name='hs_release_date' value='$row[hs_release_date]'>
						Return date:<input style='width: 140px;' class='input1' type='text' name='hs_return_date' value='$row[hs_return_date]'>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_dept' value=''>
							<option selected value=''>Currently selected: $row[hs_dept]</option>
							<option value='ABMP / FO'>ABMP / FO</option>
							<option value='ACCOUNTING'>ACCOUNTING</option>
							<option value='BILLING'>BILLING</option>
							<option value='CONSOLTANT'>CONSOLTANT</option>
							<option value='CRM DEV'>CRM DEV</option>
							<option value='DAVAO'>DAVAO</option>
							<option value='DESIGNER'>DESIGNER</option>
							<option value='EDITOR'>EDITOR</option>
							<option value='EVENTS'>EVENTS</option>
							<option value='FINANCE'>FINANCE</option>
							<option value='FO'>FO</option>
							<option value='HR'>HR</option>
							<option value='IT'>IT</option>
							<option value='IT MANAGER'>IT MANAGER</option>
							<option value='MARKETING M.'>MARKETING</option>
							<option value='PDEV'>PDEV</option>
							<option value='QA'>QA</option>
							<option value='SALES'>SALES</option>
							<option value='SALES MANAGER'>SALES MANAGER</option>
							<option value='SEO'>SEO</option>
							<option value='TECH ASS'>TECH ASS</option>
							<option value='TL PROD'>TL PROD</option>
							<option value='WEB DEV'>WEB DEV</option>
							<option value='WRITER'>WRITER</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_space' value=''>
							<option selected value=''>Currently selected: $row[hs_space]</option>
							<option value='EXPANSION'>EXPANSION</option>
							<option value='OLD OPS'>OLD OPS</option>
						</select>
					</td>
				</tr>
				<tr>
					<td>
						<textarea style='width: 500px; height: 50px' class='input1' type='text' name='hs_remarks' rows='10' col='30' value='$row[hs_remarks]' placeholder='Remarks'></textarea>
					</td>
				</tr>				
				<tr>
					<td>
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 18px;
							width: 505px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;' 
							name='hs_stat' value=''>
							<option selected value=''><b>STATUS</b></option>
							<option value='ACTIVE'>ACTIVE</option>
							<option value='FOR REPAIR'>FOR REPAIR</option>
							<option value='SPARE'>SPARE</option>
							<option value='DEFECTIVE / FOR DISPOSAL'>DEFECTIVE / FOR DISPOSA</option>
						</select>
					</td>
				</tr>";
			}							
			echo "
				<tr>
					<td style='padding-left:20px;'><input style='padding-right:182px; padding-left:182px;' class='btn' type='submit' name='updatehead' value='Update Headset'></td>
				</tr>
				</form>
				</table>
				</fieldset>
		</div>
	</div>";
		}
		}	
		mysqli_close($connection);
			?>
	<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>