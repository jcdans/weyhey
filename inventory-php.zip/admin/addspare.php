<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../admin/header.php"; ?>
	<div class="headerconfirm">
		<?php
			if(isset($_POST['addspare']))
			{
				include '../connection.php';
				
				$sp_asset = $_POST['sp_asset'];
				$sp_model = $_POST['sp_model'];
				$sp_brand = $_POST['sp_brand'];
				$sp_type = $_POST['sp_type'];
				$sp_status = $_POST['sp_status'];
				$sp_space = $_POST['sp_space'];
				$sp_remarks = $_POST['sp_remarks'];
				
				if(!$connection) 
				{ 
					die('Connection Failed: ' . mysqli_connect_error());
				}
				$sql = "INSERT INTO spare (sp_asset, sp_model, sp_brand, sp_type, sp_status, sp_space, sp_remarks) 
						VALUES ('$sp_asset', '$sp_model', '$sp_brand', '$sp_type', '$sp_status', '$sp_space', '$sp_remarks')";
						
				if(mysqli_multi_query($connection, $sql)) 
				{	
					echo "<div class='headerconfirm' style='background-color:#47a3da;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Successfully Saved.</b>
						</td></tr></table></div>
						</div>";
				}
				else 
				{
					echo "<div class='headerconfirm' style='background-color:red;'>
						<div class='container1'>
						<table align='center'>
						<tr>
						<td>
						<b class='b7'>Error in Saving.</b>
						</td></tr></table></div>
						</div>";
				}							
			mysqli_close($connection);
			}
		?>
	</div>
	
	<br/><br/>
	<div class="container1">
		<div class="addcontainer">
			<fieldset>
			</table>
				<table align="center">
				<tr>
					<td>
						<form method="POST"  action="">
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 20px;
							width: 150px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;'
							name='sp_asset' value=' ' required>
							<option selected value=''>Choose asset:</option>
							<option value='MONITOR'>MONITOR</option>
							<option value='KEYBOARD'>KEYBOARD</option>
							<option value='MOUSE'>MOUSE</option>
							<option value='RAM'>RAM</option>
							<option value='PROCESSOR'>PROCESSOR</option>
						</select>
						<input style="width: 144px;" class="input1" type="text" name="sp_model" placeholder="Model">
						<input style="width: 144px;" class="input1" type="text" name="sp_brand" placeholder="Brand">
					</td>
				</tr>
				<tr>
					<td>						
						<input style="width: 144px;" class="input1" type="text" name="sp_type" placeholder="Type">
						<select class='input1' 
							style='color: black;
							padding-left:10px;
							margin: 10px;
							margin-top: 12px;
							margin-left: 20px;
							width: 150px;
							height: 35px;
							border: 1px solid #c7d0d2;
							border-radius: 2px;
							box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #f5f7f8;
							-webkit-transition: all .4s ease;
							-moz-transition: all .4s ease;
							transition: all .4s ease;
							transition: all .4s ease;'
							name='sp_status' value=' ' required>
							<option selected value=''>Choose status:</option>
							<option value='NEW'>NEW</option>
							<option value='OLD'>OLD</option>	
							</select>
						<input style="width: 144px;" class="input1" type="text" name="sp_space" placeholder="Space">
					</td>
				</tr>
				<tr>
					<td>
						<input style="width: 514px;" class="input1" type="text" name="sp_remarks" placeholder="Remarks">
					</td>
				</tr>
				<tr>
					<td style="padding-left:20px;"><input style="padding-right:215px; padding-left:215px;" class="btn" type="submit" name="addspare" value="Add Spare"></td>
				</tr>
				</form>
				</table>
				</fieldset>
			</div>
		</div>
		<br/><br/>
		<center class='input1'><a href="../admin/mainpage.php">Back</a></center>
		<?php include "../admin/footer.php"; ?>
	</body>
</html>