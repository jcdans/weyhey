<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
		<?php
			$inserted = FALSE;
			session_start();
			include '../connection.php';
			include '../PHPExcel/IOFactory.php';
			
			$objPHPExcel = PHPExcel_IOFactory::load('spare-inventory.xlsx');
			foreach ($objPHPExcel->getWorksheetIterator() as $worksheet)
			{
				$highestRow = $worksheet->getHighestRow();
				for ($row = 0; $row <= $highestRow; $row++)
				{
					$sp_asset = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(0, $row)->getValue());
					$sp_model = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(1, $row)->getValue());
					$sp_brand = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(2, $row)->getValue());
					$sp_type = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(3, $row)->getValue());
					$sp_status = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(4, $row)->getValue());
					$sp_space = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(5, $row)->getValue());
					$sp_remarks = mysqli_real_escape_string($connection, $worksheet->getCellByColumnAndRow(6, $row)->getValue());
					
					if ($sp_asset != "" && ($sp_asset == "MONITOR" || $sp_asset == "KEYBOARD" || $sp_asset == "MOUSE" || $sp_asset == "RAM" || $sp_asset == "PROCESSOR"))
					{
						$sql = "INSERT INTO spare (sp_asset, sp_model, sp_brand, sp_type, sp_status, sp_space, sp_remarks) 
								VALUES ('".$sp_asset."', '".$sp_model."', '".$sp_brand."', '".$sp_type."', '".$sp_status."', '".$sp_space."', '".$sp_remarks."')";

						date_default_timezone_set('Asia/Manila');
						$last_mod = date('F d Y H:i:s.');
						 if(!isset($_SESSION)) 
						    { 
						        session_start(); 
						    } 
						$_SESSION['lastmodspare'] = date('F d Y H:i:s.');
						mysqli_query($connection, $sql);
						$inserted = TRUE;
					}
				}
			}
			if($inserted === TRUE){
						date_default_timezone_set('Asia/Manila');
						$modDATE = date('F d Y H:i:s.');
						$modTYPE = "Spare";
						 if(!isset($_SESSION)){ 
						        session_start(); 
						} 
						$user = $_SESSION['username'];
						$pass = $_SESSION['userpass'];
						
						$sqlemp = "SELECT * FROM employee WHERE emp_user = '$user'"; 
						$rs_employee = mysqli_query($connection, $sqlemp);
						if (mysqli_num_rows($rs_employee) > 0){
							while ($row = mysqli_fetch_assoc($rs_employee)){
								$modFName = $row["emp_fname"];
								$modMName = $row["emp_midinit"];
								$modLName = $row["emp_lname"];
							}
							$MODNAME = $modFName . " " . $modMName . ". " . $modLName;
						}
						$sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'";
						$sqlmodupdate = "UPDATE modification set mod_name = '$MODNAME', mod_date = '$modDATE' WHERE mod_type = '$modTYPE'";
						$sqlmodinsert = "INSERT INTO modification VALUES ('$MODNAME', '$modDATE', '$modTYPE')";
						$rs_mod = mysqli_query($connection, $sqlmod);
						if(mysqli_num_rows($rs_mod) > 0){
							mysqli_query($connection, $sqlmodupdate);
						}
						else
						{
							mysqli_query($connection, $sqlmodinsert);
						}
			}
		?>
		<br/><br/><br/><br/><br/>
		<?php 
		if($inserted){
			echo "
		<center class='input1'>Congratulations! Data inserted!</center>";
		}
		else{
			echo "
		<center class='input1'>Data insertion failed!</center>";
		}
		header('Refresh:2; url=upload.php');?>
	</body>
</html>