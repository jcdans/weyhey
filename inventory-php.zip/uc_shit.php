<html>
	<head>
		<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.4/angular.min.js"></script>
	</head>

	<body>
		<div ng-app="">
			<input type="text" ng-model="data" name="input_text">
			<br><br>

			<h1>{{ data }}</h1>
		</div>
	</body>
</html>