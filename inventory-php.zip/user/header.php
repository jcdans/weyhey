<div class="wrapper">
	<header>
		<div class="container1">
			<table>
				<tr>
					<td style="padding:left:300px; padding-top:35px;"><a href="../user/mainpage.php"><img src="../logo1.png" width="390px"></a></td>
					<td style="padding-left:500px"></td>
					<td>
					<?php
						if(!isset($_SESSION)) 
					    { 
					        session_start(); 
					    } 
						$username = $_SESSION['username'].'▾';
						if($_SESSION['logged'] == true) 
						{ 
							if($_SESSION['emp_type'] == 'USER')
							{
								echo "<ul id='nav'>
									<li><a class='fly' href='#' tabindex='1'>$username</a>
									<ul class='dd'>
										<li><a href='../user/profile.php'><b class='b11'>Profile</b></a></li>
										<li><a href='logout.php'><b class='b11'>Logout</b></a></li>
									</ul>
								</ul>";
							}
							else
							{
								header('Refresh:0; url=../user/mainpage.php');
							}
						}
						else 
						{
							header('Refresh:0; url=/inventory-php');
						}
					?>
					</td>
				</tr>
			</table>
		</div>
	</header>
	<hr>
	<table align = "center">
		<tr>
			<td>
				<ul id='nav'>
					<li><a class='fly' href='../user/sum.php'><img src='../pics/btnSum.png' height='115px' width='115px'></a></li>
				</ul>
			</td>
			<td>
				<ul id='nav'>
					<li><a class='fly' href='../user/log.php'><img src="../pics/btnLog.png" height="115px" width="115px"></a></li>
				</ul>
			</td>
			<td>
				<ul id='nav'>
				<?php 
			include "../connection.php";
			//include "../connect.php";
			
			mysqli_select_db($connection, "inventory");

			// DESKTOP

			$resultdesk1 = mysqli_query($connection, "SELECT * FROM desktop WHERE desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk1 = mysqli_num_rows($resultdesk1);

			//active
			$resultdesk2 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'ACTIVE' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk2 = mysqli_num_rows($resultdesk2);

			//for repair
			$resultdesk3 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'FOR REPAIR' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk3 = mysqli_num_rows($resultdesk3);

			//defective
			$resultdesk4 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'DEFECTIVE / FOR DISPOSAL' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk4 = mysqli_num_rows($resultdesk4);

			//spare
			$resultdesk5 = mysqli_query($connection, "SELECT desk_stat FROM desktop WHERE desk_stat = 'SPARE' AND desk_hname != 'VACANT' AND desk_type != 'LAPTOP'");
			$num_rowsdesk5 = mysqli_num_rows($resultdesk5);

			$desk = "A total of: $num_rowsdesk1 desktop(s)
Active: $num_rowsdesk2
For Repair: $num_rowsdesk3
Defective / For disposal: $num_rowsdesk4
Spare: $num_rowsdesk5
";

				echo "<li><a class='fly' href='../user/desktop.php' title='$desk'><img src='../pics/btnDesk.png' height='115px' width='115px'></a></li>";?>				
				</ul>
			</td>				
			<td>
				<ul id='nav'>
				<?php 
			include "../connection.php";
			
			mysqli_select_db($connection, "inventory");

			// HEADSET

			$resulthead1 = mysqli_query($connection, "SELECT * FROM headset");
			$num_rowshead1 = mysqli_num_rows($resulthead1);

			//active
			$resulthead2 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'ACTIVE'");
			$num_rowshead2 = mysqli_num_rows($resulthead2);

			//missing
			$resulthead3 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'MISSING'");
			$num_rowshead3 = mysqli_num_rows($resulthead3);

			//for repair
			$resulthead4 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'FOR REPAIR'");
			$num_rowshead4 = mysqli_num_rows($resulthead4);

			//defective
			$resulthead5 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'DEFECTIVE / FOR DISPOSAL'");
			$num_rowshead5 = mysqli_num_rows($resulthead5);

			//spare
			$resulthead6 = mysqli_query($connection, "SELECT hs_stat FROM headset WHERE hs_stat = 'SPARE'");
			$num_rowshead6 = mysqli_num_rows($resulthead6);

			$head = "A total of: $num_rowshead1 headset(s)
Active: $num_rowshead2
Missing: $num_rowshead3
For Repair: $num_rowshead4
Defective / For disposal: $num_rowshead5
Spare: $num_rowshead6
			";
					echo "<li><a class='fly' href='../user/headset.php' title='$head'><img src='../pics/btnHead.png' height='115px' width='115px'></a></li>";?>			
				</ul>
			</td>
			<td>
				<ul id='nav'>
				<?php 
			include "../connection.php";
			
			mysqli_select_db($connection, "inventory");

			// LAPTOP

			$resultlap1 = mysqli_query($connection, "SELECT * FROM laptop");
			$num_rowslap1 = mysqli_num_rows($resultlap1);

			//active
			$resultlap2 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'ACTIVE'");
			$num_rowslap2 = mysqli_num_rows($resultlap2);

			//for repair
			$resultlap3 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'FOR REPAIR'");
			$num_rowslap3 = mysqli_num_rows($resultlap3);

			//defective
			$resultlap4 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'DEFECTIVE / FOR DISPOSAL'");
			$num_rowslap4 = mysqli_num_rows($resultlap4);

			//spare
			$resultlap5 = mysqli_query($connection, "SELECT lap_stat FROM laptop WHERE lap_stat = 'SPARE'");
			$num_rowslap5 = mysqli_num_rows($resultlap5);

			$lap = "A total of: $num_rowslap1 laptop(s)
Active: $num_rowslap2
For Repair: $num_rowslap3
Defective / For disposal: $num_rowslap4
Spare: $num_rowslap5
			";
				echo "<li><a class='fly' href='../user/laptop.php' title='$lap'><img src='../pics/btnLap.png' height='115px' width='115px'></a></li>";?>					
				</ul>
			</td>
			<td>
				<ul id='nav'>
				<?php 
			include "../connection.php";
			
			mysqli_select_db($connection, "inventory");

			// SPARE

			//monitor
			$resultspare2 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'MONITOR'");
			$num_rowsspare2 = mysqli_num_rows($resultspare2);

			//keyboard
			$resultspare3 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'KEYBOARD'");
			$num_rowsspare3 = mysqli_num_rows($resultspare3);

			//mouse
			$resultspare4 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'MOUSE'");
			$num_rowsspare4 = mysqli_num_rows($resultspare4);

			//processor
			$resultspare5 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'RAM'");
			$num_rowsspare5 = mysqli_num_rows($resultspare5);

			//processor
			$resultspare6 = mysqli_query($connection, "SELECT sp_asset FROM spare WHERE sp_asset = 'PROCESSOR'");
			$num_rowsspare6 = mysqli_num_rows($resultspare6);

			$spare = "Monitor: $num_rowsspare2
Keyboard: $num_rowsspare3
Mouse: $num_rowsspare4
RAM: $num_rowsspare5
Processor: $num_rowsspare6
			";
					echo "<li><a class='fly' href='../user/spare.php' title='$spare'><img src='../pics/btnSpare.png' height='115px' width='115px'></a></li>";?>			
				</ul>
			</td>
		</tr>
	</table>