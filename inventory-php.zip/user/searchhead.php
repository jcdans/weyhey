<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<div class='container1'>
		<section>
		<?php
		if (isset($_POST['submitSearch']))
		{
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$search_value = $_POST["search"];
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM headset WHERE hs_num LIKE '%$search_value%'
					OR hs_serial LIKE '%$search_value%'  
					OR hs_release_to_real LIKE '%$search_value%' 
					OR hs_release_to_phone LIKE '%$search_value%' 
					OR hs_release_by LIKE '%$search_value%' 
					OR hs_status LIKE '%$search_value%' 
					ORDER BY hs_num ASC LIMIT $start_from, $num_rec_per_page"; 
			$resSearch = mysqli_query($connection, $sql); //run the query
			if (mysqli_num_rows($resSearch) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
		<section>
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>Headset No.</th>
				<th>Brand</th>
				<th>Model</th>
				<th>Serial</th>
				<th>Type</th>
				<th>Status</th>
				<th>Availability</th>
				<th colspan='2' style='font-size:13px'>Released to:<br/>Real name | Phone name</th>
				<th>Release date</th>
				<th>Return date</th>
				<th>Released by</th>
				<th>Department</th>
				<th>Space</th>
				<th>Remarks</th>
				</tr>";	
		
				while ($rowSearch = mysqli_fetch_assoc($resSearch)) 
				{
					$wordwrap = wordwrap($rowSearch['hs_remarks'], 50, '<br/>', true);

					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a title='$rowSearch[hs_space]' value='$rowSearch[hs_num]'>$rowSearch[hs_num]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_brand]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_model]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_serial]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_type]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_status]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_avail]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_release_to_real]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_release_to_phone]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_release_date]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_return_date]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_release_by]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_dept]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$rowSearch[hs_space]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$rowSearch[hs_num]'>$wordwrap</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					</section>";
				
				$sql1 = "SELECT * FROM headset"; 

					$resSearch = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($resSearch);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<a href='headset.php?page=1'>".'|<'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='headset.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='headset.php?page=$total_pages'>".'>|'."</a> "; // Goto last page
				}
			else 
			{
				echo "
				<table align:left>
					<tr>
						<td>No headsets found.</td>
					</tr>
				</table>";
			}	
		}
		?>		
		</section>
		</div>
		<table align = 'center'>
		<tr>
			<td>
				<br/><br/>
			</td>
		</tr>
		<tr>
			<td align = "center"><a href='headset.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>