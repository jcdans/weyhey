<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<div class='container1'>
		<section>
		<?php
		if (isset($_POST['submitSearch']))
		{
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$filter = $_POST["filter"];
			$search_value = $_POST["search"];
			$start_from = ($page - 1) * $num_rec_per_page; 
			switch ($filter) {
				case 'row':
					$sql = "SELECT * FROM laptop WHERE lap_row = '%$search_value%'"; 
					break;

				case 'hostname':
					$sql = "SELECT * FROM laptop WHERE lap_host LIKE '%$search_value%'"; 
					break;

				case 'serial':
					$sql = "SELECT * FROM laptop WHERE lap_serial LIKE '%$search_value%'"; 
					break;

				case 'model':
					$sql = "SELECT * FROM laptop WHERE lap_model LIKE '%$search_value%'"; 
					break;

				case 'processor':
					$sql = "SELECT * FROM laptop WHERE lap_processor LIKE '%$search_value%'"; 
					break;

				case 'ram':
					$sql = "SELECT * FROM laptop WHERE lap_ram LIKE '%$search_value%'"; 
					break;

				case 'hd':
					$sql = "SELECT * FROM laptop WHERE lap_hd LIKE '%$search_value%'"; 
					break;

				case 'type':
					$sql = "SELECT * FROM laptop WHERE lap_type LIKE '%$search_value%'"; 
					break;

				case 'os':
					$sql = "SELECT * FROM laptop WHERE lap_os LIKE '%$search_value%'"; 
					break;

				case 'ms':
					$sql = "SELECT * FROM laptop WHERE lap_ms LIKE '%$search_value%'"; 
					break;

				case 'dept':
					$sql = "SELECT * FROM laptop WHERE lap_dept LIKE '%$search_value%'"; 
					break;

				case 'space':
					$sql = "SELECT * FROM laptop WHERE lap_space LIKE '%$search_value%'"; 
					break;

				case 'remarks':
					$sql = "SELECT * FROM laptop WHERE lap_user_remarks LIKE '%$search_value%'"; 
					break;

				default:
					$sql = "SELECT * FROM laptop";

					break;
			}
			$resSearch = mysqli_query($connection, $sql); //run the query
					if (mysqli_num_rows($resSearch) > 0){
					echo "
					</section>
					</div>		
					<br/>
					<section>
					<table align='center'> 
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					 </table>						
					
					<table class='table1'>
						<tr>
					<th>Row</th>
					<th>Hostname</th>
					<th>Serial No.</th>
					<th>Model</th>
					<th>Processor</th>
					<th>RAM</th>
					<th>HD</th>
					<th>Type</th>
					<th>Operating System</th>
					<th>Microsoft Office</th>
					<th>Department</th>
					<th>Space</th>
					<th>User/Remarks</th>
					</tr>";		
			
					while ($rowSearch = mysqli_fetch_assoc($resSearch)) 
					{
						echo "	
						<tr class='tr1'>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_row]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a title='$rowSearch[lap_space]' value='$rowSearch[lap_host]'>$rowSearch[lap_host]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_serial]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_model]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_processor]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_ram]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_hd]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_type]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_os]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_ms]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_dept]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_space]</a></td>
							<td class='td1' style='text-align:left; font-size: 12px;'>
							<a value='$rowSearch[lap_host]'>$rowSearch[lap_user_remarks]</a></td>

						</tr>";
					}
						echo"</table>
						<section>
						<table>
							<tr>
								<td></td>
							</tr>
							<tr>
								<td></td>
							</tr>
						</table>
						</section>";
					
					$sql1 = "SELECT * FROM laptop"; 

						$rs_result = mysqli_query($connection, $sql1); //run the query
						$total_records = mysqli_num_rows($rs_result);  //count number of records
						$total_pages = ceil($total_records / $num_rec_per_page); 

						// echo "<a href='laptop.php?page=1'>".'|<'."</a> "; // Goto 1st page  

						// for ($i=1; $i<=$total_pages; $i++) 
						// { 
						// 	echo "<a href='laptop.php?page=".$i."'>".$i."</a> "; 
						// }
						// echo "<a href='laptop.php?page=$total_pages'>".'>|'."</a> "; // Goto last page
					}
				else 
				{
					echo "
					<table align:left>
						<tr>
							<td>No laptops found.</td>
						</tr>
					</table>";
				}	
			
		}
		?>		
		</section>
		</div>
		<table align = 'center'>
		<tr>
			<td>
				<br/><br/>
			</td>
		</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>