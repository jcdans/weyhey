<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<table align = "center">
			<tr>
				<td style='padding-left:500px'>
				<form action="searchdesk.php" method="post">
				<a class="input1">Filter Search:</a>
				<select name="filter" id="select1" required>
						<option value="">Choose filter option</option>
		                <option value="asset">Asset</option>
		                <option value="model">Model</option>
		                <option value="brand">Brand</option>
		                <option value="type">Type</option>
		                <option value="status">Status</option>
		                <option value="space">Space</option>
		                <option value="remarks">Remarks</option>
			        </select>
					<input id="inp1" style="width: 180px;" class="input1" type="text" name="search" placeholder="Search" autofocus required>
					<input type='submit' name='submitSearch' value='Search'>
				</form>
				</td>
			</tr>
		</table>
		<h3 style="text-align: center;">PERIPHERALS</h3>
		<div class="container1">
		<section>
		<?php
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM spare	ORDER BY sp_type ASC LIMIT $start_from, $num_rec_per_page"; 
			$rs_result = mysqli_query($connection, $sql); //run the query
			
			if (mysqli_num_rows($rs_result) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
		
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>Asset</th>
				<th>Model</th>
				<th>Brand</th>
				<th>Type</th>
				<th>Status</th>
				<th>Space</th>
				<th>Remarks</th>
				</tr>";		
		
				while ($row = mysqli_fetch_assoc($rs_result)) 
				{
					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_asset]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_model]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_brand]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_type]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_status]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_space]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[sp_type]'>$row[sp_remarks]</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					</section>";
				
				$sql1 = "SELECT * FROM spare"; 

					$rs_result = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($rs_result);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<section><a href='spare.php?page=1'>".'First page'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='spare.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='spare.php?page=$total_pages'>".'Last page'."</a> "; // Goto last page
		}		
		else 
		{
			echo "
			<table align:left>
				<tr>
					<td>No spare found.</td>
				</tr>
			</table>";
		}	
		?>	
		</section>
		</div>
		<br/><br/>
		<table align = "center">
		<tr>
			<td class="input1">
			<?php
			 $modTYPE = "Spare";
			 $sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'"; 
						$rs_modification = mysqli_query($connection, $sqlmod);
						if (mysqli_num_rows($rs_modification) > 0){
							while ($row = mysqli_fetch_assoc($rs_modification)){
								$modName = $row["mod_name"];
								$modDate = $row["mod_date"];
							}
							echo "Last modified: " . $modDate . " By: " .$modName;
						}

			

			?>
			</td>
		</tr>
		<tr>
			<td align = "center" class='input1'><center><br/><br/><br/><a href='../admin/mainpage.php'>Back</a></center></td>
		</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>