<?php session_start(); ?>
<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
		<script>
		
		$(document).ready(function () {

			var sel2 = document.getElementById("select2")
			var sel3 = document.getElementById("select3")
			var sel4 = document.getElementById("select4")
			var sel5 = document.getElementById("select5")
			var sel6 = document.getElementById("select6")		
			var i1 = document.getElementById("inp1")
			
			$(sel3).hide();
			$(sel4).hide();
			$(sel2).hide();
			$(sel5).hide();
			$(sel6).hide();
			$(i1).hide();
		    $("#select1").change(function () {
		        var val = $(this).val();
			    
		        if (val == "row") {

		        	sel2.setAttribute('required','required');
			     	sel3.removeAttribute('required');
			     	sel4.removeAttribute('required');
			     	sel5.removeAttribute('required');
			     	sel6.removeAttribute('required');
			     	i1.removeAttribute('required');
			     	$(i1).hide();
			     	$(sel4).hide();
		        	$(sel3).hide();
		        	$(sel5).hide();
		        	$(sel6).hide();
		        	$(sel2).show();
		        	// $(btn).hide(); 
		        }
		        else if (val == "") {
		        	
		        	// sel3.setAttribute('required','required');
		        	// sel2.removeAttribute('required');
		        	
		        	$(i1).hide();
		        	$(sel2).hide();
		        	$(sel3).hide();
		        	$(sel4).hide();
		        	$(sel5).hide();
		        	$(sel6).hide();
		        	// $(btn).hide(); 
		        }
		        else if (val == "hostname") {
		        	
		        	// sel3.setAttribute('required','required');
		        	// sel2.removeAttribute('required');
		        	sel3.setAttribute('required','required');
			     	sel2.removeAttribute('required');
			     	sel4.removeAttribute('required');
			     	sel5.removeAttribute('required');
			     	sel6.removeAttribute('required');
			     	i1.removeAttribute('required');
		        	$(i1).hide();
		        	$(sel2).hide();
		        	$(sel3).show();
		        	$(sel4).hide();
		        	$(sel5).hide();
		        	$(sel6).hide();
		        	// $(btn).hide(); 
		        }
		        else if (val == "motherboard") {
		        	
		        	// sel3.setAttribute('required','required');
		        	// sel2.removeAttribute('required');
		        	sel4.setAttribute('required','required');
			     	sel2.removeAttribute('required');
			     	sel3.removeAttribute('required');
			     	sel5.removeAttribute('required');
			     	sel6.removeAttribute('required');
			     	i1.removeAttribute('required');
		        	$(i1).hide();
		        	$(sel3).hide();
		        	$(sel2).hide();
		        	$(sel4).show();
		        	$(sel5).hide();
		        	$(sel6).hide();
		        	// $(btn).hide(); 
		        }
		        else if (val == "processor") {
		        	
		        	// sel3.setAttribute('required','required');
		        	// sel2.removeAttribute('required');
		        	sel4.removeAttribute('required');
		        	sel5.setAttribute('required','required');
		        	sel6.removeAttribute('required');
			     	sel2.removeAttribute('required');
			     	sel3.removeAttribute('required');
			     	i1.removeAttribute('required');
		        	$(i1).hide();
		        	$(sel3).hide();
		        	$(sel2).hide();
		        	$(sel4).hide();
		        	$(sel5).show();
		        	$(sel6).hide();
		        	// $(btn).hide(); 
		        }
		        else if (val == "ram") {
		        	
		        	// sel3.setAttribute('required','required');
		        	// sel2.removeAttribute('required');
		        	sel4.removeAttribute('required');
		        	sel6.setAttribute('required','required');
		        	sel5.removeAttribute('required');
			     	sel2.removeAttribute('required');
			     	sel3.removeAttribute('required');
			     	i1.removeAttribute('required');
		        	$(i1).hide();
		        	$(sel3).hide();
		        	$(sel2).hide();
		        	$(sel4).hide();
		        	$(sel6).show();
		        	$(sel5).hide();
		        	// $(btn).hide(); 
		        } else{

		        	// $(btn).show(); 
		        	$(sel3).hide();
		        	$(sel4).hide();
		        	$(sel5).hide();
		        	$(sel6).hide();
		        	$(i1).show();
		            $(sel2).hide();
		        	i1.setAttribute('required','required');
			     	sel2.removeAttribute('required');
			     	sel3.removeAttribute('required');
			     	sel4.removeAttribute('required');
			     	sel5.removeAttribute('required');
			     	sel6.removeAttribute('required');
		        }
		    });
		});
		</script>
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<table align = "center">
			<tr>
				<td style='padding-left:500px'>
				<form action="searchdesk.php" method="post">
				<a class="input1">Filter Search:</a>
				<select name="filter" id="select1" required>
						<option value="">Choose filter option</option>
		                <option value="row">Row</option>
		                <option value="hostname">Hostname</option>
		                <option value="motherboard">MotherBoard</option>
		                <option value="processor">Processor</option>
		                <option value="ram">RAM</option>
		                <option value="hd">HD</option>
		                <option value="primarymonitor">Primary Monitor</option>
		                <option value="secondarymonitor">Secondary Monitor</option>
		                <option value="type">Type</option>
		                <option value="keyboard">Keyboard</option>
		                <option value="mouse">Mouse</option>
		                <option value="os">Operating System</option>
		                <option value="ms">Microsoft Office</option>
		                <option value="dept">Department</option>
		                <option value="space">Space</option>
		                <option value="remarks">Remarks</option>
		                <option value="stat">Status</option>
			        </select>

			        <select id="select2" name="filterrow" required>
			        <?php
								$sql = "SELECT distinct * FROM desktop GROUP BY desk_row ORDER BY convert('row', int)"; 
							$resultproc = mysqli_query($connection, $sql);
							
							

							 echo "<option value=''>-- select one -- </option>";
							while($rows = mysqli_fetch_assoc($resultproc)){
								if($rows[desk_row]!=null)
								  echo "<option value='$rows[desk_row]'>$rows[desk_row]</option>";
							}
					   ?>
					</select>

					<select id="select3" name="filterhn" required>
			        <?php
							$sql = "SELECT distinct * FROM desktop GROUP BY desk_hname ORDER BY convert('desk_hname', int)"; 
							$resultproc = mysqli_query($connection, $sql);
							

							 echo "<option value=''>-- select one -- </option>";
							while($rows = mysqli_fetch_assoc($resultproc)){
								if($rows[desk_hname]!=null)
								  echo "<option value='$rows[desk_hname]'>$rows[desk_hname]</option>";
							}
					   ?>
					</select>

					<select id="select4" name="filtermb" required>
			        <?php
							$sql = "SELECT distinct * FROM desktop GROUP BY desk_mb ORDER BY convert('desk_mb', int)"; 
							$resultproc = mysqli_query($connection, $sql);
							

							 echo "<option value=''>-- select one -- </option>";
							while($rows = mysqli_fetch_assoc($resultproc)){
								if($rows[desk_mb]!=null)
								  echo "<option value='$rows[desk_mb]'>$rows[desk_mb]</option>";
							}
					   ?>
					</select>

					<select id="select5" name="filterproc" required>
			        <?php
							$sql = "SELECT distinct * FROM desktop GROUP BY desk_processor ORDER BY convert('desk_processor', int)"; 
							$resultproc = mysqli_query($connection, $sql);
							

							 echo "<option value=''>-- select one -- </option>";
							while($rows = mysqli_fetch_assoc($resultproc)){
								if($rows[desk_processor]!=null)
								  echo "<option value='$rows[desk_processor]'>$rows[desk_processor]</option>";
							}
					   ?>
					</select>

					<select id="select6" name="filterram" required>
			        <?php
							$sql = "SELECT distinct * FROM desktop GROUP BY desk_ram ORDER BY convert('desk_ram', int)"; 
							$resultproc = mysqli_query($connection, $sql);
							

							 echo "<option value=''>-- select one -- </option>";
							while($rows = mysqli_fetch_assoc($resultproc)){
								if($rows[desk_ram]!=null)
								  echo "<option value='$rows[desk_ram]'>$rows[desk_ram]</option>";
							}
					   ?>
					</select>



					<input id="inp1" style="width: 180px;" class="input1" type="text" name="search" placeholder="Search" autofocus required>
					<input type='submit' name='submitSearch' value='Search'>
				</form>
				</td>
			</tr>
		</table>
		<h3 style="text-align: center;">DESKTOP</h3>
		<div class="container1">
		<section>
		<?php
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM desktop ORDER BY convert('desk_row', int), convert('desk_hname', int) LIMIT $start_from, $num_rec_per_page"; 
			$rs_result = mysqli_query($connection, $sql); //run the query
			
			if (mysqli_num_rows($rs_result) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
	
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>ROW</th>
				<th>Hostname</th>
				<th>MotherBoard</th>
				<th>Processor</th>
				<th>RAM</th>
				<th>HD</th>
				<th>Primary Monitor</th>
				<th>Secondary Monitor</th>
				<th>Type</th>
				<th>Keyboard</th>
				<th>Mouse</th>
				<th>Operating System</th>
				<th>Microsoft Office</th>
				<th>Department</th>
				<th>Space</th>
				<th>Remarks</th>
				</tr>";		
		
				while ($row = mysqli_fetch_assoc($rs_result)) 
				{
					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_row]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a title='$row[desk_space]' value='$row[desk_row]'>$row[desk_hname]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_mb]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_processor]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_ram]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_hd]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_monitor_p]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_monitor_s]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_type]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_kb]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_mouse]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_os]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_ms]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_dept]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_space]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[desk_row]'>$row[desk_remarks]</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					";
				
				$sql1 = "SELECT * FROM desktop"; 

					$rs_result = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($rs_result);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<a href='desktop.php?page=1'>".'First'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='desktop.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='desktop.php?page=$total_pages'>".'Last'."</a> "; // Goto last page

		}								
		else 
		{
			echo "
			<table align:left>
				<tr>
					<td>No desktops found.</td>
				</tr>
			</table>";
		}	
		?>	
		</section>
		</div>
		<table align = "center">
		<tr>
			<td>
				<br/><br/>
			</td>
		</tr>
		<tr>
			<td align = "center"><a href='../user/mainpage.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>