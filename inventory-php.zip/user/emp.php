<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<br/><br/><br/>
		<?php
			include '../connection.php';
			$num_rec_per_page = 5; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}
			if (isset($_GET["page"])) 
			{ 
				$page = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$start_from = ($page - 1) * $num_rec_per_page;
			
			$sql = "SELECT * FROM employee
					INNER JOIN images
					ON employee.emp_user = images.img_user
					WHERE employee.emp_user != 'itsupport' 
					ORDER BY employee.emp_fname 
					ASC LIMIT $start_from, $num_rec_per_page";
			$result = mysqli_query($connection, $sql);
			if (mysqli_num_rows($result) > 0) 
			{
				while ($row = mysqli_fetch_assoc($result)) 
				{
					echo "
			<table align = 'center' class='table1'>
			<tr>
				<td>
					<table class='table1'>
						<tr>
							<td><img height='150' width='150' src='data:image/jpeg;base64,".base64_encode( $row['image'] )."'/><</td>
						</tr>
					</table>
				</td>
				<td>
					<table class='table1'>
						<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Name: <b><a value='$row[emp_user]'>$row[emp_fname]</a></b>
						<b><a value='$row[emp_user]'>$row[emp_midinit]</a></b>
						<b><a value='$row[emp_user]'>$row[emp_lname]</a></b></td></tr>
						<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Address: <b><a value='$row[emp_user]'>$row[emp_address]</a></b></td></tr>
						<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Birthday: <b><a value='$row[emp_user]'>$row[emp_bday]</a></b></td></tr>
						<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Cellphone number: <b><a value='$row[emp_user]'>$row[emp_cellnum]</a></b></td></tr>
						<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Email: <b><a value='$row[emp_user]'>$row[emp_email]</a></b></td></tr>
					</table>
				</td>
			</tr>
			</table>
					";
				}
				$sql1 = "SELECT * FROM employee"; 

				$result = mysqli_query($connection, $sql1); //run the query
				$total_records = mysqli_num_rows($result);  //count number of records
				$total_pages = ceil($total_records / $num_rec_per_page); 

				echo "<br/><center>";
				echo "<a href='emp.php?page=1'>".'|<'."</a> "; // Goto 1st page  

				for ($i=1; $i<=$total_pages; $i++) 
				{ 
					echo "<a href='emp.php?page=".$i."'>".$i."</a> "; 
				}
				echo "<a href='emp.php?page=$total_pages'>".'>|'."</a> "; // Goto last page
				echo "</center>";
			}
			else
			{
				echo "
					<table align:left>
						<tr>
							<td>No employees found.</td>
						</tr>
					</table>";
			}
		?>
		<table align = "center">
			<tr>
				<td><br/><br/></td>
			</tr>
			<tr>
				<td class='input1'><a href="../user/mainpage.php">Back</a></td>
			</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>