<div class="container1">
	<br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
	<br/><br/><br/><br/><br/>
	<br/><br/>
</div>
<footer>
	<div class="container1">
	<table align="left">
	<tr>
		<td style="padding-top:20px"><img src="../logo1-footer.png"></td>
	</tr>
	</table>
	<table align="center">
		<tr>
			<td>
				<ul class="ul3">
					<li><i><a href="log.php">Recent Logs</a></i></li>
					<li><a href="desktop.php">Desktop</a></li>
					<li><a href="headset.php">Headset</a></li>
					<li><a href="laptop.php">Laptop</a></li>
					<li><a href="spare.php">Spare</a></li>
				</ul>
			</td>
		</tr>
		<tr>
			<td></td>
		</tr>
		<tr style="float:left;">
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">DESKTOP</a></li>
					<li><a href="desktop.php" style="font-size:12px; color:darkgray;">Show Desktops</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">HEADSET</a></li>
					<li><a href="headset.php" style="font-size:12px; color:darkgray;">Show Headsets</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">LAPTOP</a></li>
					<li><a href="laptop.php" style="font-size:12px; color:darkgray;">Show Laptops</a></li>
				</ul></td>
			<td><ul class="ul4" style="float:left;">
					<li><a style="color:white; font-weight:bold;">SPARE</a></li>
					<li><a href="laptop.php" style="font-size:12px; color:darkgray;">Show Spares</a></li>
				</ul></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
		<tr>
			<td><br/></td>
		</tr>
	</table>
	</div>
</footer>
<footer class="footer2">
	<div class="container1">
		<table>
			<tr>
				<td><span>Copyright © 2016-2017 Willver de Jesus, and Commercial Reach Inc. All rights reserved.</span></td>
			</tr>
		</table>
	</div>
</footer>
</div>