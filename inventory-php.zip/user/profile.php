<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<br/><br/><br/>
		<table align = "center" class='table1'>
			<tr>
				<td>
					<table class='table1'>
						<tr>
							<td><?php
								include '../connection.php';
								$username = $_SESSION['username'];
								if(!$connection) 
								{ 
									die('Connection Failed: ' . mysqli_connect_error());
								}
								$sqlimage = "SELECT * FROM images WHERE img_user = '$username'";
								$imageresult = mysqli_query($connection, $sqlimage);

								if (mysqli_num_rows($imageresult) > 0)
								{
									while($rowImg = mysqli_fetch_assoc($imageresult))
									{
										echo "<img height='150' width='150' src='data:image/jpeg;base64,".base64_encode( $rowImg['image'] )."'/>
											</td>
										</tr>
										<tr>
											<td align = 'center' class = 'input1'><a href='../user/uploadpic2.php'><u>Change</u></a></td>
										</tr>
										";
									}
								}
								else
								{
									echo "<img height='150' width='150' src='../pics/user-icon.png'/>
										</td>
										</tr>
										<tr>
											<td align = 'center' class = 'input1'><a href='../user/uploadpic.php'><u>Upload</u></a></td>
										</tr>
										";
								}
					    		?>
					</table>
				</td>
				<td>
					<table class='table1'>
						<?php
							include '../connection.php';
							if(!$connection) 
							{ 
								die('Connection Failed: ' . mysqli_connect_error());
							}
							$username = $_SESSION['username'];
							$sql = "SELECT * FROM employee WHERE emp_user LIKE '$username'";
							$result = mysqli_query($connection, $sql);
							while ($row = mysqli_fetch_assoc($result)) 
							{
								echo "
									<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Username: <b><a value='$row[emp_user]'>$row[emp_user]</a></b></td></tr>
									<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Name: <b><a value='$row[emp_user]'>$row[emp_fname]</a></b>
									<b><a value='$row[emp_user]'>$row[emp_midinit]</a></b>
									<b><a value='$row[emp_user]'>$row[emp_lname]</a></b></td></tr>
									<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Address: <b><a value='$row[emp_user]'>$row[emp_address]</a></b></td></tr>
									<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Birthday: <b><a value='$row[emp_user]'>$row[emp_bday]</a></b></td></tr>
									<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Cellphone number: <b><a value='$row[emp_user]'>$row[emp_cellnum]</a></b></td></tr>
									<tr class='tr1'><td class='td1; input1' style='text-align:left; font-size: 12px;'>Email: <b><a value='$row[emp_user]'>$row[emp_email]</a></b></td></tr>
								";
							}
						?>
					</table>
				</td>
			</tr>
		</table>
		<table align = "center">
			<tr>
				<td class='input1'><a href='../user/empedit.php' style='padding-left:500px'>Edit</a></td>
			</tr>
			<tr>
				<td><br/><br/></td>
			</tr>
			<tr>
				<td align="center" class='input1'><a href="../user/mainpage.php">Back</a></td>
			</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>