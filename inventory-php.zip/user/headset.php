<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<table align = "center">
			<tr>
				<td style="padding-left:670px"><form action="searchhead.php" method="post">
				<a class="input1">Filter Search:</a>
				<select name="filter" required>
						<option value="">Choose filter option</option>
		                <option value="headno">Headset No.</option>
		                <option value="brand">Brand</option>
		                <option value="model">Model</option>
		                <option value="serial">Serial</option>
		                <option value="type">Type</option>
		                <option value="stat">Status</option>
		                <option value="availability">Availability</option>
		                <option value="releasedtoreal">Released to Real Name</option>
		                <option value="releasedtophone">Released to Phone Name</option>
		                <option value="releasedate">Release Date</option>
		                <option value="returndate">Return Date</option>
		                <option value="releaseby">Released by</option>
		                <option value="deparment">Department</option> 
		                <option value="space">Space</option> 
		                <option value="remarks">Remarks</option>  	            
			        </select>
					<input style="width: 180px;" class="input1" type="text" name="search" placeholder="Search" autofocus required>
					<input type="submit" name="submitSearch" value="Search">
				</form>
				</td>
			</tr>
		</table>
		 <h3 style="text-align: center;">HEADSET</h3>
		<div class="container1">
		<section>
		<?php
			include '../connection.php';						
			$num_rec_per_page = 10; 
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM headset ORDER BY convert('hs_num', int) LIMIT $start_from, $num_rec_per_page"; 
			$rs_result = mysqli_query($connection, $sql); //run the query
			
			if (mysqli_num_rows($rs_result) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
		
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>Headset No.</th>
				<th>Brand</th>
				<th>Model</th>
				<th>Serial</th>
				<th>Type</th>
				<th>Status</th>
				<th>Availability</th>
				<th colspan='2' style='font-size:13px'>Released to:<br/>Real name | Phone name</th>
				<th>Release date</th>
				<th>Return date</th>
				<th>Released by</th>
				<th>Department</th>
				<th>Space</th>
				<th>Remarks</th>
				</tr>";		
		
				while ($row = mysqli_fetch_assoc($rs_result)) 
				{
					$wordwrap = wordwrap($row['hs_remarks'], 50, '<br/>', true);
					
					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a title='$row[hs_space]' value='$row[hs_num]'>$row[hs_num]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_brand]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_model]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_serial]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_type]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_status]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_avail]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_release_to_real]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_release_to_phone]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_release_date]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_return_date]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_release_by]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_dept]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$row[hs_space]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[hs_num]'>$wordwrap</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					</section>";
				
				$sql1 = "SELECT * FROM headset"; 

					$rs_result = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($rs_result);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<section> <a href='headset.php?page=1'>".'First page'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='headset.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='headset.php?page=$total_pages'>".'Last page'."</a> "; // Goto last page

		}								
		else 
		{
			echo "
			<table align:left>
				<tr>
					<td>No headsets found.</td>
				</tr>
			</table>";
		}	
		?>	
		</section>
		</div>
		<br/><br/>
		<table align = "center">
		<tr>
			<td class="input1">
			<?php
			 $modTYPE = "Headset";
			 $sqlmod = "SELECT * FROM modification WHERE mod_type = '$modTYPE'"; 
						$rs_modification = mysqli_query($connection, $sqlmod);
						if (mysqli_num_rows($rs_modification) > 0){
							while ($row = mysqli_fetch_assoc($rs_modification)){
								$modName = $row["mod_name"];
								$modDate = $row["mod_date"];
							}
							echo "Last modified: " . $modDate . " By: " .$modName;
						}

			

			?>
			</td>
		</tr>
		<tr>
			<td align = "center" class='input1'><br/><br/><br/><a href='../admin/mainpage.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>