<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
	<?php include "../user/header.php"; ?>
		<table align = "center">
			<tr>
				<td style="padding-left:710px"><form action="searchlog.php" method="post">
					<input style="width: 180px;" class="input1" type="text" name="search" placeholder="Search" autofocus>
					<input type="submit" name="submitSearch" value="Search">
				</form>
				</td>
			</tr>
		</table>
		<div class="container1">
		<section>
		<?php
			include '../connection.php';						
			$num_rec_per_page = 10;
			if(!$connection) 
			{ 
				die('Connection Failed: ' . mysqli_connect_error());
			}	
			if (isset($_GET["page"])) 
			{ 
				$page  = $_GET["page"]; 
			} 
			else 
			{
				$page = 1; 
			}
			$start_from = ($page - 1) * $num_rec_per_page; 
			$sql = "SELECT * FROM log ORDER BY log_date ASC LIMIT $start_from, $num_rec_per_page"; 
			$rs_result = mysqli_query($connection, $sql); //run the query
			
			if (mysqli_num_rows($rs_result) > 0) 
			{
				echo "
		</section>
		</div>		
		<br/>
		<section>
		<table align='center'> 
			<tr>
				<td></td>
			</tr>
			<tr>
				<td></td>
			</tr>
		 </table>						
		
		<table class='table1'>
			<tr>
				<th>DATE</th>
				<th>ACTIVITIES / TASK DONE / TRANSACTIONS</th>
				<th>REMARKS</th>
				</tr>";		
		
				while ($row = mysqli_fetch_assoc($rs_result)) 
				{
					$wordwrap1 = wordwrap($row['log_act'], 50, '<br/>', true);
					$wordwrap2 = wordwrap($row['log_status'], 50, '<br/>', true);

					echo "	
					<tr class='tr1'>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[log_date]'>$row[log_date]</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[log_date]'>$wordwrap1</a></td>
						<td class='td1' style='text-align:left; font-size: 12px;'>
						<a value='$row[log_date]'>$wordwrap2</a></td>
					</tr>";
				}
					echo"</table>
					<section>
					<table>
						<tr>
							<td></td>
						</tr>
						<tr>
							<td></td>
						</tr>
					</table>
					</section>";
				
				$sql1 = "SELECT * FROM log"; 

					$rs_result = mysqli_query($connection, $sql1); //run the query
					$total_records = mysqli_num_rows($rs_result);  //count number of records
					$total_pages = ceil($total_records / $num_rec_per_page); 

					echo "<a href='log.php?page=1'>".'|<'."</a> "; // Goto 1st page  

					for ($i=1; $i<=$total_pages; $i++) 
					{ 
						echo "<a href='log.php?page=".$i."'>".$i."</a> "; 
					}
					echo "<a href='log.php?page=$total_pages'>".'>|'."</a> "; // Goto last page

		}								
		else 
		{
			echo "
			<table align:left>
				<tr>
					<td>No logs found.</td>
				</tr>
			</table>";
		}	
		?>	
		</section>
		</div>
		<br/><br/>
		<table align = "center">
		<tr>
			<td align = "center" class='input1'><a href='../user/mainpage.php'>Back</a></td>
		</tr>
		</table>
		<?php include "../user/footer.php"; ?>
	</body>
</html>