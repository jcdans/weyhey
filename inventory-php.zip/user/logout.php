<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="../css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="../logo.png">
	</head>
	<body>
		<?php
			session_start();
			unset($_SESSION['username']);
			session_destroy();
			echo "<br/><br/><br/><br/><br/><br/><br/><br/><h1 class='input1' style='font-size:30px'><center>See you again!</center></h1>";
			header("Refresh:1; url=/inventory-php");
			exit;
		?>
	</body>
</html>