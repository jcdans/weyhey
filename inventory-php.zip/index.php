<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="logo.png">
	</head>
	<body>
	<div class="wrapper">
		<br/><br/><br/><br/><br/><br/><br/><br/>
		<?php
		 if(!isset($_SESSION)) 
					    { 
					        session_start(); 
					    } 
		if(isset($_SESSION['username'])) {
	
			if($_SESSION['emp_type'] == 'ADMIN'){
   			header('Refresh:0; url=/inventory-php/admin/mainpage.php');
   			}
   			else{
   				header('Refresh:0; url=/inventory-php/user/mainpage.php');
   			}
   			exit;
		}

		?>
		<div class="container1">
			<table align = "center">
				<td style="padding-left:10px"><img src="logo1.png" height="125px" width="700px"></td>
			</table>
		<table align="center">
		<form method="POST" action="">
			<tr>
				<td>Username: </td>
				<td><input class="input1" type="text" name="emp_user" placeholder="username" autofocus required/></td>
			</tr>
			<tr>
				<td>Password: </td>
				<td><input class="input1" type="password" name="emp_pass" placeholder="password" required/></td>
			</tr>
		</table>
		<table align = "center">
			<b><center style="font-size:12px">Forgot your password? <a href="email.php">Email me!</a></center></b>
		</table>
		<br/><br/>
		<table align="center">
			<tr>
				<td><input type="submit" name="login" value="LOGIN"/></td>
			</tr>
			<tr>
				<td>
				<?php
					 if(!isset($_SESSION)) 
					    { 
					        session_start(); 
					    } 
					if(isset($_POST['login']))
					{
						include 'connection.php';
						$username = trim($_POST['emp_user']);
						$userpass = trim($_POST['emp_pass']);
						
						if(!$connection)
						{
							die('Connection Failed: ' . mysqli_connect_error());
						}
						$sql = "SELECT * FROM employee WHERE emp_user = '$username' AND emp_pass = '$userpass'";
						$result = mysqli_query($connection, $sql);
						if(mysqli_fetch_row($result) > 0)
						{
							$sql2 = "SELECT emp_type FROM employee WHERE emp_user = '$username'";
							$result = mysqli_query($connection, $sql2);
							$row = mysqli_fetch_row($result);
							$emp_type = $row[0];
							if($emp_type == 'USER')
							{
								$_SESSION['username'] = $username;
								$_SESSION['userpass'] = $userpass;
								$_SESSION['logged'] = true;
								$_SESSION['emp_type'] = 'USER';
								header('Refresh:0; url=loading.php');
								exit;
							}
							else
							{
								$_SESSION['username'] = $username;
								$_SESSION['userpass'] = $userpass;
								$_SESSION['logged'] = true;
								$_SESSION['emp_type'] = 'ADMIN';
								header('Refresh:0; url=loading.php');
								exit;
							}
						}
						else 
						{
							echo 
							"<table align='center'>
								<tr>
									<td><b class='b1'>Invalid username or password.</b></td>
								</tr>
							</table>";
						}

						mysqli_close($connection);
					}
				?>
				</td>
			</tr>
		</form>
		</table>
		</div>
		<div class="container1">
			<br/><br/><br/><br/><br/>
			<br/><br/><br/><br/><br/>
			<br/><br/><br/><br/><br/>
			<br/><br/><br/><br/><br/>
			<br/><br/>
		</div>
		<footer class="footer2">
			<div class="container1">
				<table>
					<tr>
						<td><span>Copyright © 2016-2017 Commercial Reach Inc. All rights reserved.</span></td>
					</tr>
				</table>
			</div>
		</footer>
		</div>
	</div>
	</body>
</html>