<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="logo.png">
	</head>
	<body>
	<div class="wrapper">
		<br/><br/><br/><br/><br/><br/><br/><br/>
		<div class="container1">
			<div class="change">
				<table align="center">
					<tr>
						<br/>
						<td style="padding-left:50px;"><img src="logo.png" height="125px" width="125px"></td>
					</tr>
				</table>
				<table align="center">
					<form method="POST" action="">
					<tr>
						<td><input class='input1' type='email' name='emp_email' placeholder='example@email.com' autofocus required/></td>
					</tr>
					<tr>
						<td><input class='input1' type='email' name='emp_email2' placeholder='Confirm email' required/></td>
					</tr>
					<tr>
						<td style='padding-left:16px;'><input class='btn' style='padding-left:108px; padding-right:108px;'type='submit' name='emailsend' value='Send'></td>  
					</tr>
					<tr>
						<td><?php
							if(isset($_POST['emailsend']))
							{	
								include 'connection.php';
								
								$email = $_POST['emp_email'];
								$emp_email2 = $_POST['emp_email2'];
								
								if(!$connection) 
								{ 
									die('Connection Failed: ' . mysqli_connect_error());
								}

								$sql = "SELECT emp_email FROM employee WHERE emp_email = '$email'";
								$result = mysqli_query($connection, $sql);

								if(mysqli_fetch_row($result) > 0)
								{
									if($email == $emp_email2)
									{	
										require("smtp/smtp.php");
										//require("sasl/sasl.php");
										$from = '$emp_email2';
										$to = 'edwardsamson.cri@gmail.com';

										$smtp=new smtp_class;
										$smtp->host_name="smtp.mandrillapp.com";
										$smtp->host_port='587';
										$smtp->user='$emp_email2';
										$smtp->password='';
										$smtp->ssl=1;
										$smtp->debug=0;      //0 here in production
										$smtp->html_debug=0; //same

										$smtp->SendMessage($from,array($to),array(
										"From: $from",
										"To: $to",
										"Subject: Forgot password",
										"Date: ".strftime("%a, %d %b %Y %H:%M:%S %Z")
										),
										"Hello IT Support Team,\n\nIt is just to let you know that I want to change my password.\n\nBye.\n");
										
										echo "<table align='center'>
											<tr>
												<td><b class='b1' style='color:blue;'>Email has been sent! Thank you for your patience.</b></td>
											</tr>
										</table>
										<center><a href='/inventory-php' class='input1'>Back</a></center>";
										exit;
									}
									else 
									{
										echo "<table align='center'>
												<tr>
													<td><b class='b1'>Email does not match the confirm email.</b></td>
												</tr>
											</table>";
									}
								}
								else
								{
									echo "<table align='center'>
												<tr>
													<td><b class='b1'>Email not found in database.</b></td>
												</tr>
											</table>";
								}
								mysqli_close($connection);
							}
						?></td>
					</tr>
					</form>
				</table>
			<br/><br/>
			<center style="padding-left:50px"><a href='/inventory-php' class='input1'>Back</a></center>
			</div>
		</div>
	</div>
	</body>
</html>