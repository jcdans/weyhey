<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/default.css">
		<title>Clickable Brand Inc.</title>
		<link rel="shortcut icon" href="logo.png">
	</head>
	<body>
	<?php
		session_start();
		//$username = $_SESSION['username'];
		$userpword = $_SESSION['userpass'];
		$emp_type = $_SESSION['emp_type'];
		//if($userpword == 123)
		//{
		//	header('Refresh:2; url=changepass.php');
		//	echo "<center>Did you forgot your password, ".$username."?</center>";
		//}
		if ($emp_type == 'USER')
		{
			header('Refresh:1; url=user/mainpage.php');
			echo "<br/><br/><br/><br/><br/><br/><br/><br/><h1 class='input1' style='font-size:30px'><center>Welcome!</center></h1>";
		}
		else
		{
			header('Refresh:1; url=admin/mainpage.php');
			echo "<br/><br/><br/><br/><br/><br/><br/><br/><h1 class='input1' style='font-size:30px'><center>Welcome!</center></h1>";
		}
	?>
	</body>
</html>