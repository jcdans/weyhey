<?php
	/*******EDIT LINES 3-8*******/
	$DB_Server = "127.0.0.1"; //MySQL Server    
	$DB_Username = "root"; //MySQL Username     
	$DB_Password = ""; //MySQL Password     
	$DB_DBName = "inventory"; //MySQL Database Name
?>